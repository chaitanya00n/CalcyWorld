# Calcyworld — Install Guide (हिंदी में)

**Calcyworld by Rezoic** · 2 हिस्से: **Plugin** (`calcyworld-core.zip`) + **Theme** (`calcyworld-theme.zip`).
Plugin में 2,327 calculators/converters और सारा engine है। Theme में पूरा design, header/footer, home page और SEO pages हैं।

> पहले यह जान लें: मैंने असली theme/plugin code एक test-setup में चलाकर जाँचा है (सभी 2,327 tool pages Chrome में mobile पर खोले, और 233 pages desktop पर भी)। लेकिन **असली WordPress सर्वर पर इसे मैं यहाँ नहीं चला सका** (मेरे पास WordPress/इंटरनेट नहीं है)। इसलिए पहले इसे **staging / नई खाली site** पर install करें, फिर live करें। कोई दिक्कत आए तो error का screenshot भेज दीजिए — ठीक कर दूँगा।

---

## 0. पुरानी Calcyworld site को अपडेट करना हो तो (पहले यह पढ़ें)
1. **Backup लें** (hosting का backup या कोई backup plugin)।
2. *Appearance → Themes → Add New → Upload Theme* → `calcyworld-theme.zip` → WordPress पूछेगा "Replace current with uploaded" → वो चुनें।
3. *Plugins → Add New → Upload Plugin* → `calcyworld-core.zip` → वही "Replace current with uploaded"।
4. बस। अगली बार कोई भी page खुलते ही plugin एक बार अपने-आप यह करता है:
   - **जिन pages का text आपने खुद नहीं बदला** (About, How it works, Privacy Policy, Terms, Disclaimer) उन्हें नए, बेहतर text से बदल देता है। **जो page आपने खुद edit किया है उसे छूता नहीं।**
   - नए pages बनाता है: *How it works*, *Categories*, *Popular*।
   - Menus नए बनाता है (Calculators, Converters, Categories, Popular, Blog, About)।
   - **6 असली blog posts** डालता है और WordPress का default "Hello world!" post और "Sample Page" हटा देता है (सिर्फ़ तब जब वे अब भी वैसे ही हों जैसे WordPress ने बनाए थे)।
   - हर page में SEO description भर देता है (अगर खाली थी)।
   - **Contact page हटा देता है:** अगर पुरानी site पर plugin वाला Contact page है और आपने उसे खुद edit नहीं किया, तो वह **Trash** में चला जाता है (चाहें तो *Pages → Trash* से वापस ला सकते हैं), menu/footer से उसका link हट जाता है, और About, Privacy, Terms, Disclaimer में उसकी तरफ़ जाते वाक्य हटा दिए जाते हैं। **अगर आपने Contact page खुद बदला है तो वह जैसा है वैसा रहता है।**
   - **Tool के नाम SEO-friendly कर देता है** (जैसे "AED to EUR — UAE Dirham to Euro" → "AED to EUR Converter (UAE Dirham to Euro)", "Atbash Cipher" → "Atbash Cipher Encoder & Decoder")। **जिस tool का नाम आपने खुद बदला है उसे नहीं छूता**, और tool का URL कभी नहीं बदलता, इसलिए कोई link नहीं टूटता। साथ में हर tool में *Search keywords* भर देता है (खाली हों तो)।
5. *Settings → Permalinks → Save* एक बार दबा दें।
6. Cache plugin हो तो cache clear करें।

---

## 1. जो चाहिए
- WordPress **6.0 या नया**, PHP **7.4 या नया** (PHP 8.x बढ़िया है)
- Hosting जहाँ आप plugin/theme upload कर सकें (cPanel / Hostinger / Bluehost / कोई भी)
- एक **नई (fresh) WordPress site** सबसे आसान रहती है

## 2. नई site पर install करने के steps
1. **Theme:** WordPress Admin → *Appearance → Themes → Add New → Upload Theme* → `calcyworld-theme.zip` चुनें → *Install Now* → **अभी Activate न करें**, पहले plugin।
2. **Plugin:** *Plugins → Add New → Upload Plugin* → `calcyworld-core.zip` → *Install Now* → **Activate**।
3. Activate होते ही plugin अपने आप यह सब बना देता है:
   - 20 Categories + 119 Sub-categories (हर एक का अपना अलग SEO page)
   - Home, All Calculators, All Converters, Categories, Popular, How it works, Blog, About, Privacy Policy, Terms, Disclaimer — ये सब normal WordPress *Pages* हैं
   - Menus, और 6 शुरुआती blog posts
   - पहले 40 calculators के pages। **बाकी pages background में अपने-आप बनते रहते हैं** (सस्ती hosting पर भी time-out नहीं होता)।
4. **Calcyworld → Dashboard** खोलिए। वहाँ **Progress bar** दिखेगी। उस page को खुला रखें तो तेज़ी से बनता है; बंद कर दें तो भी WP-Cron पीछे बनाता रहेगा। (SSH हो तो `wp calcyworld import` भी चलता है।) 2,327 pages बनने में कुछ मिनट लगते हैं।
5. अब **Appearance → Themes → Calcyworld → Activate**।
6. **Settings → Permalinks** खोलें और **Post name** चुनकर *Save* कर दें (सिर्फ एक बार; इससे `/calculators/finance/loans-emi/` जैसे URLs चलते हैं)।
7. **Settings → Reading** में देखें: *Your homepage displays → A static page*, Homepage = **Home**, Posts page = **Blog** (plugin यह खुद set कर देता है, बस जाँच लें)।

## 3. अपनी पहचान बदलना (Customizer)
*Appearance → Customize → Calcyworld*:
- **Design style (नया):** *Colours & style → Design style* में दो रूप हैं — **Classic** (सपाट cards; यही default है) और **Soft** (layout बिल्कुल वही — ऊपर menu, बीच में बड़ा headline और search — बस रूप बदलता है: गोल कोनों वाला frame और नरम panel, raised सफ़ेद cards, soft shadow, काले icon tiles, dark navy cards)। बदलकर *Publish* दबाइए — fonts, accent रंग, tools, SEO और सारे pages वही रहते हैं। कभी भी वापस Classic कर सकते हैं।
- **Colours & style:** accent colour (बदलने पर buttons, links **और सारे icons** सब उसी रंग में बदल जाते हैं), default Day/Night mode, Google Fonts चालू/बंद
- **Home page:** headline (खाली छोड़ने पर "Calculate anything. Convert anything." दिखता है और visitor की भाषा में अपने-आप अनुवाद होता है), intro, search placeholder, 4 number tiles / live rates / blog चालू-बंद
- **Footer & credits:** brand name, about, copyright, **"Powered by" = Rezoic** (नाम और link बदल सकते हैं), disclaimer, social links
- Logo: *Site Identity* में अपना logo डालें
- Menus: *Appearance → Menus* — Primary menu में Calculators, Converters, Categories, Popular, Blog, About पहले से हैं। जितने चाहें और pages जोड़ें/हटाएँ।

## 4. Home page का हर हिस्सा कहाँ से बदलें
| हिस्सा | कहाँ |
|---|---|
| Headline, intro, search box का text | Customizer → Calcyworld → Home page |
| Search के नीचे वाले category names | अपने-आप, *Calculators → Categories* के क्रम से (क्रम बदलने के लिए हर category का **Order** बदलें) |
| "Popular in India" (देश के हिसाब से बदलता है) | अपने-आप visitors के उपयोग से; शुरू की list *Calcyworld → Settings → Starter lists by country* में |
| Browse by category (icon + tools की असली गिनती) | अपने-आप, categories से |
| SEO वाला लेख (Calcyworld क्या है) | *Pages → Home* में Block editor से लिखें |
| Latest posts | *Posts* से |

## 5. हर Category और Sub-category अलग editable पेज
*Calculators → Categories* में किसी भी category/sub-category को Edit करें। वहाँ ये सब अपना लिख सकते हैं:
SEO Title, Meta Description, Icon, Colour, Order, Intro text, लंबा text (SEO content), FAQ।
Front-end पर "Finance" खोलने पर उसकी sub-categories दिखती हैं, "Loans & EMI" पर उसके tools।

## 6. हर Calculator भी अलग editable पेज
*Calculators → All calculators* → कोई भी tool Edit करें: title, URL, Block-editor में लंबा लेख, Formula, FAQ, और नीचे **"Calculator setup"** box में ये चार चीज़ें:
- **Search keywords** — लोग इस tool को और किन नामों से खोजते हैं, comma से अलग करके (जैसे EMI के लिए `equated monthly instalment, loan emi kaise nikale, ईएमआई कैलकुलेटर`)। Site की search इन शब्दों से भी वही tool खोल देती है, और ये page के structured data में भी जाते हैं।
- **SEO title** (चाहें तो) — Google में दिखने वाली लाइन। खाली छोड़ें तो अपने-आप बनती है ("नाम – Free & Instant | Site", लगभग 60 अक्षर तक)।
- **SEO description** (चाहें तो) — लगभग 150 अक्षर। खाली छोड़ें तो tool के छोटे text से अपने-आप पूरी बनती है।
- **Icon** — खाली छोड़ें तो tool के नाम से अपने-आप सही icon चुना जाता है; चाहें तो सूची से खुद चुनें।

**नया calculator बिना code के:** *Calculators → Add new* → नीचे **"Calculator setup"** box → Mode = *Custom* → inputs, outputs और formula लिखें।

सब pages (About, Privacy…, All Calculators, All Converters आदि) *Pages* में हैं। हर page में **Excerpt** भरें — वही Google को दिखने वाला meta description बनता है। (Excerpt box न दिखे तो ऊपर *Screen Options* में tick करें।)

## 7. Blog
*Posts → Add New*। हर post के card पर एक icon अपने-आप लगता है। चाहें तो post में Custom Field **`_cw_art`** बनाकर किसी category का icon चुन सकते हैं (जैसे `finance`, `health`, `math`, `converters`)। Featured image लगाएँ तो वह दिखेगी।

## 8. खोज (Search) और देश/भाषा
- **Search:** header की search या home की बड़ी search में "bmi" लिखकर Enter दबाएँ तो सीधे BMI Calculator का अपना page खुलता है। Tool का पूरा नाम लिखने पर वही tool खुलता है; "eur to aed" और "aed to eur" अलग-अलग सही tool खोलते हैं; और हर tool के *Search keywords* (ऊपर 6) से भी मिलता है — जैसे "dollar to rupee", "umar calculator", "ईएमआई कैलकुलेटर"। जिस खोज का कोई साफ़ मेल न हो उसका normal results page दिखता है। यह बंद करना हो तो *Calcyworld → Settings → Search* का tick हटाएँ।
- **देश चुनने पर भाषा भी बदलती है:** visitor जो देश चुने (UAE → अरबी और दाएँ-से-बाएँ layout, Brazil → Portuguese, Mexico → Spanish…) उसकी भाषा अपने-आप लग जाती है, और एक "Undo" बटन भी दिखता है। देश और भाषा **दोनों अलग-अलग** चुनने के बटन header में हैं। अगर visitor ने भाषा खुद चुनी है तो देश बदलने पर वह भाषा नहीं बदलती।
- **अपनी जोड़ी बनानी हो:** *Calcyworld → Settings → Language by country* में लिखें, जैसे `IN=hi` (India के लिए हिन्दी)। **शुरू में India की default भाषा English है।** Hindi चाहिए तो यह जोड़ी लिखें।

## 9. Auto-update क्या-क्या होता है
| चीज़ | कैसे |
|---|---|
| **Currency rates** | दिन में 2 बार server खुद `open.er-api.com` से लेता है (free)। अपनी paid API का URL भी *Calcyworld → Settings* में डाल सकते हैं |
| **Crypto prices** | CoinGecko से दिन में 2 बार (Settings में बंद भी कर सकते हैं) |
| **Visitor का देश / currency / भाषा** | Browser के time-zone और language से अपने-आप (कोई IP lookup या outside service नहीं) |
| **"Popular in India/USA/…"** | हर देश के visitors जो tools खोलते हैं, उनसे सीखता रहता है (कोई cookie नहीं, IP नहीं रखता) |
| **Day/Night** | Visitor के device की setting के हिसाब से, और वो खुद बदल भी सकता है |

अगर आपकी hosting बाहर के requests रोकती है तो rates नहीं आएँगे — *Calcyworld → Dashboard → Update rates now* दबाकर देखें; वहाँ error भी लिखा आता है।

## 10. Ads (बाद में कमाई के लिए)
*Calcyworld → Ads*: ads **शुरू में बंद** हैं। जब तैयार हों तो switch ON करें, AdSense Publisher ID (`ca-pub-…`) या अपना ad code (Ezoic/Mediavine/banner) अलग-अलग slots में paste करें, `ads.txt` भी वहीं से बनता है (अगर आपकी site में असली ads.txt file पहले से न हो)। जिस slot में कुछ न डालें वो दिखता ही नहीं और जगह भी नहीं घेरता। किसी एक calculator पर ads बंद करने के लिए उसके edit page पर "Hide ads on this page" tick करें।

## 11. भाषाएँ
Interface (menus, बटन, calculator के अंदर के बटन, home) **10 भाषाओं** में है: English, हिन्दी, Español, Français, Deutsch, Português, العربية (RTL), Bahasa Indonesia, বাংলা, Русский।
**Calculator का नाम / category का नाम / लंबा लेख / calculator के अंदर के field-labels** English में रहते हैं। इन्हें भी अनुवाद करना हो तो **Polylang, WPML या TranslatePress** लगाएँ, और *Calcyworld → Settings* में "I use a multilingual plugin" tick कर दें।

## 12. SEO — क्या अपने-आप होता है
- हर page का अपना title, meta description, canonical और social-share tags
- **Tool के नाम में हमेशा वही शब्द होते हैं जो लोग Google में लिखते हैं** ("… Calculator", "… Converter", "… Encoder & Decoder"), और कोई दो tools का नाम एक जैसा नहीं है (Google को duplicate न दिखें)
- Tool का title लगभग 60 अक्षर के अंदर रखा जाता है (लंबा नाम हो तो site का नाम हटाकर), और meta description 120–155 अक्षर की बनती है
- Home पर Organization schema, calculators पर tool schema, जिन pages में FAQ (`<details>`) है वहाँ FAQ schema
- XML sitemap WordPress खुद बनाता है (`/wp-sitemap.xml`); Google Search Console में डालें
- हर page का **SEO text आप खुद बदल सकते हैं** (ऊपर 4–6 देखें)। अच्छे नतीजों के लिए हर category/sub-category में अपना intro और FAQ लिखें — सबसे ज़्यादा असर वहीं होता है।
- मैं **ranking की गारंटी नहीं दे सकता** — वो content, site की उम्र और backlinks पर निर्भर करती है।

## 13. Speed / Cache
- कोई भी cache plugin (LiteSpeed, WP Rocket, W3 Total Cache) चलेगा। Calculators पेज में हर tool की सिर्फ़ अपनी छोटी JS file load होती है।
- Cache के साथ "देश का पता" पूरी तरह browser में होता है, इसलिए cached page सबको सही चलता है।
- **Cloudflare** हो तो *Settings → "Use CDN country header"* ऑन कर सकते हैं (सिर्फ़ तब जब pages सबके लिए एक जैसे cache न हों)।

## 14. ध्यान दें (ईमानदार बातें)
1. **Privacy / Terms / Disclaimer pages एक अच्छी शुरुआत हैं, पर कानूनी सलाह नहीं।** Launch से पहले पढ़ें, अपने देश के नियम/नाम/पते के हिसाब से बदलें।
2. **Google Fonts** (Bricolage Grotesque + Manrope) default में चालू हैं। Strict privacy / GDPR चाहिए तो Customizer में बंद कर दें — तब system font चलेगा। (Privacy Policy में यह लिखा है।)
3. कुछ tools के उदाहरण **USD** में लिखे हैं, पर calculator खुद visitor की currency में चलता है।
4. **हर देश का VAT/GST rate** *Calcyworld → Country presets* में editable है (ये अपने-आप live नहीं बदलता)। **Income-tax slabs, सरकारी दरें और limits** calculators के code में बने हुए हैं, admin से नहीं बदलते — हर बजट/नए वित्त-वर्ष के बाद जाँचकर plugin का update निकालना होगा। त्योहारों की तारीखें approximate हैं।
5. Health calculators सिर्फ़ जानकारी के लिए हैं — page पर disclaimer दिखता है।
6. Google Fonts बंद हों तो हिन्दी/बांग्ला/अरबी के लिए सिस्टम का अपना font दिखेगा।

## 15. Coverage (कितने tools)
*Calcyworld → Tool coverage* में पूरी सूची और गिनती है।
- कुल tools: **2,327** (Converters: **827**)
- Categories: **20**, Sub-categories: **119**
- आपकी research list (894 items): **810 सीधे बने**, **79 किसी दूसरे tool में शामिल** (same काम, अलग नाम), **5 नहीं बने**: Age-based Weight Chart, Baby Gender Predictor, Baby Growth Percentile, Child BMI Percentile, Pin Code to Pin Code Distance (इनके लिए भरोसेमंद डेटा / सर्वर-API चाहिए)

## 16. दिक्कत आए तो
| समस्या | हल |
|---|---|
| Category/tool का page 404 दे रहा है | *Settings → Permalinks → Save* दबाएँ |
| Calculators के pages कम हैं | *Calcyworld → Dashboard* खोलकर progress bar पूरी होने दें |
| Rates नहीं दिख रहे | *Dashboard → Update rates now*; hosting ने outgoing requests रोके हों तो host से पूछें |
| Design टूटा-सा लगे | Cache clear करें (plugin + browser), और जाँचें कि **Calcyworld theme active** है |
| अपडेट के बाद पुराना text दिख रहा है | उस page का text आपने पहले बदला था, इसलिए plugin ने उसे छुआ नहीं। चाहें तो उसे हाथ से नए text से बदल लें |
| बहुत सारे pages के बाद site धीमी | अच्छा cache plugin लगाएँ; shared hosting पर PHP 8.1+ और 256MB memory रखें |

**Contact page:** Calcyworld अब कोई Contact page नहीं बनाता। बाद में चाहें तो *Pages → Add New* से अपना बना लें और Menus में जोड़ लें।

सहायता: *Calcyworld → Help*।
