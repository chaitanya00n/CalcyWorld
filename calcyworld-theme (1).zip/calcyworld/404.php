<?php
/**
 * Not found.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
$pop = post_type_exists( 'calculator' ) ? get_posts( array( 'post_type' => 'calculator', 'posts_per_page' => 8, 'meta_key' => '_cw_popular', 'meta_value' => '1', 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true ) ) : array();
?>
<section class="wrap nf">
	<p class="nf-code">404</p>
	<h1><?php esc_html_e( 'That page doesn’t exist.', 'calcyworld' ); ?></h1>
	<p class="lede"><?php esc_html_e( 'The link may be old or mistyped. Search for the calculator you need, or start from the home page.', 'calcyworld' ); ?></p>
	<?php get_search_form(); ?>
	<p><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>" <?php echo cwt_di( 'home' ); // phpcs:ignore ?>><?php cwt_e( 'home' ); ?></a></p>
	<?php if ( $pop ) : ?>
		<ul class="tgrid nf-list">
			<?php foreach ( $pop as $p ) { cwt_card( $p ); } ?>
		</ul>
	<?php endif; ?>
</section>
<?php
get_footer();
