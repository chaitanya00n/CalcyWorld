<?php
/**
 * Template Name: Popular Calculators
 *
 * The tools people use most in the visitor's country (filled in by the browser), with a server-rendered fallback.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
$pop = array();
if ( post_type_exists( 'calculator' ) ) {
	$pop = get_posts( array( 'post_type' => 'calculator', 'posts_per_page' => 24, 'meta_key' => '_cw_popular', 'meta_value' => '1', 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true ) );
}
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>
	<header class="chero">
		<div class="chero-t">
			<h1 class="js-popular-title" data-tpl="<?php echo esc_attr( cwt_t( 'popular_in' ) ); ?>"><?php cwt_e( 'popular' ); ?></h1>
			<?php
			while ( have_posts() ) :
				the_post();
				if ( trim( get_the_content() ) ) {
					echo '<div class="chero-p">' . wp_kses_post( wpautop( get_the_content() ) ) . '</div>'; // phpcs:ignore
				}
			endwhile;
			?>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', 'star', 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>
	<ul class="pcards js-popular-grid" data-limit="24">
		<?php foreach ( $pop as $p ) : $sec = cw_post_section( $p->ID ); ?>
			<li><a class="pcard" href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo cwt_tile( 't', cwt_post_icon( $p ), 48, 'pc-i' ); // phpcs:ignore ?><span class="pc-t"><strong><?php echo esc_html( get_the_title( $p ) ); ?></strong><small><?php echo esc_html( $sec ? cwt_term_name( $sec ) : '' ); ?></small></span></a></li>
		<?php endforeach; ?>
	</ul>
</div>
<?php
get_footer();
