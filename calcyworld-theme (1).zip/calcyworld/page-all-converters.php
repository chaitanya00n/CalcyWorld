<?php
/**
 * Template Name: All Converters
 *
 * Every converter, grouped by category and sub-category, with a live filter.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
$cwt_kind = 'conv';
require get_template_directory() . '/template-parts/all-tools.php';
