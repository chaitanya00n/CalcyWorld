<?php
/**
 * Calcyworld theme setup.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

define( 'CWT_VERSION', '3.2.0' );

require get_template_directory() . '/inc/icons.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/art.php';

add_action(
	'after_setup_theme',
	function () {
		load_theme_textdomain( 'calcyworld', get_template_directory() . '/languages' );
		add_theme_support( 'calcyworld' ); // Tells Calcyworld Core the theme places the widget, FAQ and related blocks itself.
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'custom-logo', array( 'height' => 64, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_editor_style( 'assets/css/editor.css' );
		add_image_size( 'cwt-card', 640, 360, true );
		register_nav_menus(
			array(
				'primary'  => __( 'Main menu', 'calcyworld' ),
				'footer'   => __( 'Footer — Company links', 'calcyworld' ),
				'footer-2' => __( 'Footer — Legal links', 'calcyworld' ),
			)
		);
	}
);

add_action(
	'widgets_init',
	function () {
		$common = array(
			'before_widget' => '<section id="%1$s" class="widget g %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		);
		register_sidebar( array_merge( $common, array( 'name' => __( 'Calculator sidebar', 'calcyworld' ), 'id' => 'calc-sidebar', 'description' => __( 'Shown beside the article under a calculator (wide screens).', 'calcyworld' ) ) ) );
		register_sidebar( array_merge( $common, array( 'name' => __( 'Blog sidebar', 'calcyworld' ), 'id' => 'blog-sidebar' ) ) );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( cwt_mod( 'cwt_font' ) ) {
			wp_enqueue_style( 'cwt-font', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600..800&family=Manrope:wght@500..800&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters
		}
		wp_enqueue_style( 'calcyworld', get_template_directory_uri() . '/assets/css/theme.css', array( 'cw-engine' ), CWT_VERSION );
		if ( cwt_is_soft() ) {
			wp_enqueue_style( 'calcyworld-soft', get_template_directory_uri() . '/assets/css/soft.css', array( 'calcyworld' ), CWT_VERSION );
		}
		wp_add_inline_style( 'calcyworld', cwt_custom_css() );
		wp_enqueue_script( 'calcyworld', get_template_directory_uri() . '/assets/js/theme.js', array( 'cw-core' ), CWT_VERSION, true );
		wp_localize_script(
			'calcyworld',
			'CWT',
			array(
				'rest'    => esc_url_raw( rest_url( 'calcyworld/v1/' ) ),
				'ver'     => (int) get_option( 'cw_index_ver', 1 ),
				'search'  => esc_url( home_url( '/' ) ),
				'noJs'    => '',
			)
		);
		if ( is_singular( 'post' ) && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	},
	20
);

/* Set colour mode (and the visitor's chosen language / text direction) before the page paints: no flash. */
add_action(
	'wp_head',
	function () {
		$default = cwt_mod( 'cwt_mode' );
		$own     = function_exists( 'cw_settings' ) ? (bool) cw_settings()['own_i18n'] : true;
		$lang    = $own ? '' : "var l=localStorage.getItem('cw_lang');if(l&&/^[a-z]{2}$/.test(l)){var e=document.documentElement;e.setAttribute('lang',l);e.setAttribute('dir',l==='ar'?'rtl':'ltr');}";
		echo "<script>(function(){try{var m=localStorage.getItem('cw_theme')||" . wp_json_encode( $default ) . ";if(m==='auto'){m=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}document.documentElement.setAttribute('data-theme',m);" . $lang . "}catch(e){document.documentElement.setAttribute('data-theme','light');}})();</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta name="theme-color" content="#FFFFFF" media="(prefers-color-scheme: light)">' . "\n";
		echo '<meta name="theme-color" content="#0D0F1F" media="(prefers-color-scheme: dark)">' . "\n";
	},
	1
);

add_filter(
	'body_class',
	function ( $c ) {
		if ( cwt_is_soft() ) {
			$c[] = 'cwt-soft';
		}
		if ( is_singular( 'calculator' ) ) {
			$c[] = 'is-calculator';
		}
		if ( is_tax( 'calc_category' ) ) {
			$c[] = get_queried_object()->parent ? 'is-group' : 'is-section';
		}
		return $c;
	}
);

add_filter( 'excerpt_length', function () { return 24; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/* Menu items: mark the standard ones so the language switcher can translate them. */
add_filter(
	'nav_menu_link_attributes',
	function ( $atts, $item ) {
		$map = array(
			'Home'                 => 'home',
			'All Calculators'      => 'all_calculators',
			'Calculators'          => 'calculators',
			'Converters'           => 'converters',
			'All Converters'       => 'all_converters',
			'Categories'           => 'categories',
			'Popular'              => 'popular',
			'Blog'                 => 'blog',
			'About'                => 'about',
			'How Calcyworld Works' => 'how_it_works',
			'Privacy'              => 'privacy',
			'Privacy Policy'       => 'privacy',
			'Terms'                => 'terms',
			'Terms of Use'         => 'terms',
			'Disclaimer'           => 'disclaimer',
		);
		$title = trim( $item->title );
		if ( isset( $map[ $title ] ) ) {
			$atts['data-i'] = $map[ $title ];
		} elseif ( 'calc_category' === $item->object ) {
			$term = get_term( (int) $item->object_id, 'calc_category' );
			if ( $term && ! is_wp_error( $term ) && ! $term->parent && html_entity_decode( $term->name, ENT_QUOTES ) === $title ) {
				$atts['data-i'] = 's_' . $term->slug;
			}
		}
		return $atts;
	},
	10,
	2
);

/* A translated menu label for server-rendered languages (when the site locale is not English). */
add_filter(
	'nav_menu_item_title',
	function ( $title, $item ) {
		if ( ! function_exists( 'cw_t' ) || 'en' === cw_server_lang() ) {
			return $title;
		}
		$map = array( 'Home' => 'home', 'All Calculators' => 'all_calculators', 'Calculators' => 'calculators', 'Converters' => 'converters', 'All Converters' => 'all_converters', 'Categories' => 'categories', 'Popular' => 'popular', 'Blog' => 'blog', 'About' => 'about', 'How Calcyworld Works' => 'how_it_works', 'Privacy' => 'privacy', 'Privacy Policy' => 'privacy', 'Terms' => 'terms', 'Terms of Use' => 'terms', 'Disclaimer' => 'disclaimer' );
		$t   = trim( $title );
		if ( isset( $map[ $t ] ) ) {
			return cw_t( $map[ $t ] );
		}
		if ( 'calc_category' === $item->object ) {
			$term = get_term( (int) $item->object_id, 'calc_category' );
			if ( $term && ! is_wp_error( $term ) && ! $term->parent && html_entity_decode( $term->name, ENT_QUOTES ) === $t ) {
				return cw_section_label( $term );
			}
		}
		return $title;
	},
	10,
	2
);

/* Plugin missing? Say so politely instead of showing a broken site. */
add_action(
	'admin_notices',
	function () {
		if ( ! function_exists( 'cw_render_widget' ) && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning"><p><strong>Calcyworld theme:</strong> please install and activate the <em>Calcyworld Core</em> plugin — it provides the calculators, categories and ad slots.</p></div>';
		}
	}
);
