<?php
/**
 * Template helpers.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

/** Is the Calcyworld Core plugin active? */
function cwt_core() {
	return function_exists( 'cw_render_widget' );
}

/** Translated interface text (falls back to the key if the plugin is missing). */
function cwt_t( $key, $vars = array() ) {
	return function_exists( 'cw_t' ) ? cw_t( $key, $vars ) : $key;
}

/** Echo escaped, translatable text plus the data attribute used by the language switcher. */
function cwt_e( $key, $vars = array() ) {
	echo esc_html( cwt_t( $key, $vars ) );
}

/** data-i + data-n attributes for a templated string such as "{n} tools". */
function cwt_dn( $key, $n ) {
	return ' data-i="' . esc_attr( $key ) . '" data-n="' . (int) $n . '"';
}

/** data-i attribute for a key. */
function cwt_di( $key ) {
	return 'data-i="' . esc_attr( $key ) . '"';
}

/** Hex colour → rgba() string. */
function cwt_rgba( $hex, $a = .14 ) {
	$c = sscanf( ltrim( (string) $hex, '#' ), '%02x%02x%02x' );
	if ( ! $c || count( $c ) < 3 || null === $c[2] ) {
		return 'rgba(91,79,245,' . $a . ')';
	}
	return 'rgba(' . (int) $c[0] . ',' . (int) $c[1] . ',' . (int) $c[2] . ',' . $a . ')';
}

/** Inline style that tints a card with a category colour. */
function cwt_tint( $hex ) {
	$hex = sanitize_hex_color( $hex ) ? $hex : '#5B4FF5';
	return '--c:' . $hex . ';--cs:' . cwt_rgba( $hex, .15 );
}

/** Top-level sections (20) in display order, with counts that include their sub-categories. */
function cwt_sections() {
	if ( ! taxonomy_exists( 'calc_category' ) ) {
		return array();
	}
	$terms = get_terms( array( 'taxonomy' => 'calc_category', 'parent' => 0, 'hide_empty' => false, 'pad_counts' => true ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		return (int) get_term_meta( $a->term_id, 'cw_order', true ) - (int) get_term_meta( $b->term_id, 'cw_order', true );
	} );
	return $terms;
}

/** Sub-categories of a section, ordered. */
function cwt_subs( $parent_id ) {
	$terms = get_terms( array( 'taxonomy' => 'calc_category', 'parent' => $parent_id, 'hide_empty' => false ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		return (int) get_term_meta( $a->term_id, 'cw_order', true ) - (int) get_term_meta( $b->term_id, 'cw_order', true );
	} );
	return $terms;
}

/** The colour of a category (a sub-category uses its section's colour unless it has its own). */
function cwt_term_color( $term ) {
	$c = get_term_meta( $term->term_id, 'cw_color', true );
	if ( ! $c && $term->parent ) {
		$c = get_term_meta( $term->parent, 'cw_color', true );
	}
	return $c ? $c : '#5B4FF5';
}

/** Icon markup of a category. */
function cwt_term_icon( $term, $size = 24 ) {
	$i = get_term_meta( $term->term_id, 'cw_icon', true );
	return cwt_icon( $i ? $i : 'grid', $size );
}

/** Name of a category, translated for sections. */
function cwt_term_name( $term ) {
	return function_exists( 'cw_section_label' ) ? cw_section_label( $term ) : html_entity_decode( $term->name, ENT_QUOTES );
}

/** data-i for a section name (so the switcher can translate it). */
function cwt_term_di( $term ) {
	return $term->parent ? '' : ' data-i="s_' . esc_attr( $term->slug ) . '"';
}

/** Calculators in a term. */
function cwt_calcs_in( $term_id, $limit = -1, $children = true, $popular_first = false ) {
	$args = array(
		'post_type'      => 'calculator',
		'posts_per_page' => $limit,
		'orderby'        => $popular_first ? array( 'meta_value_num' => 'DESC', 'menu_order' => 'ASC', 'title' => 'ASC' ) : array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		'no_found_rows'  => true,
		'tax_query'      => array( array( 'taxonomy' => 'calc_category', 'terms' => $term_id, 'include_children' => $children ) ),
	);
	if ( $popular_first ) {
		$args['meta_key'] = '_cw_popular';
	}
	return get_posts( $args );
}

/** Number of tools in a category (counts sub-categories for a section). Uses the plugin's own count, so it is never 0 by mistake. */
function cwt_count( $term ) {
	return function_exists( 'cw_term_total' ) ? (int) cw_term_total( $term ) : (int) $term->count;
}

/** One tool as a row: name, the sub-category it lives in, and an arrow. No icon. */
function cwt_card( $post, $opts = array() ) {
	$post  = get_post( $post );
	$terms = get_the_terms( $post->ID, 'calc_category' );
	$g     = $terms && ! is_wp_error( $terms ) && $terms[0]->parent ? html_entity_decode( $terms[0]->name, ENT_QUOTES ) : '';
	echo '<li><a class="tool" href="' . esc_url( get_permalink( $post ) ) . '">' . cwt_tile( 't', cwt_post_icon( $post ), 40 ) . '<span class="t">' . esc_html( get_the_title( $post ) ) . ( $g ? '<small>' . esc_html( $g ) . '</small>' : '' ) . '</span>' . cwt_icon( 'chev', 16 ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/** Breadcrumbs (Home › Section › Group › Page). */
function cwt_breadcrumbs() {
	$c = array( '<a href="' . esc_url( home_url( '/' ) ) . '" ' . cwt_di( 'home' ) . '>' . esc_html( cwt_t( 'home' ) ) . '</a>' );
	$add_term = function ( $t ) use ( &$c ) {
		$c[] = '<a href="' . esc_url( get_term_link( $t ) ) . '"' . cwt_term_di( $t ) . '>' . esc_html( cwt_term_name( $t ) ) . '</a>';
	};
	if ( is_singular( 'calculator' ) ) {
		$terms = get_the_terms( get_the_ID(), 'calc_category' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$t = $terms[0];
			if ( $t->parent ) {
				$add_term( get_term( $t->parent, 'calc_category' ) );
			}
			$add_term( $t );
		}
	} elseif ( is_tax( 'calc_category' ) ) {
		$t = get_queried_object();
		if ( $t->parent ) {
			$add_term( get_term( $t->parent, 'calc_category' ) );
		}
	} elseif ( is_singular( 'post' ) ) {
		$blog = get_option( 'page_for_posts' );
		if ( $blog ) {
			$c[] = '<a href="' . esc_url( get_permalink( $blog ) ) . '" ' . cwt_di( 'blog' ) . '>' . esc_html( get_the_title( $blog ) ) . '</a>';
		}
	}
	echo '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'calcyworld' ) . '">' . implode( '<span aria-hidden="true">›</span>', $c ) . '</nav>'; // phpcs:ignore
}

/** Print an ad slot (the plugin decides whether ads are on). */
function cwt_ad( $slot ) {
	if ( function_exists( 'cw_ad' ) ) {
		cw_ad( $slot );
	}
}

/** Social links row. */
function cwt_social() {
	$out = '';
	foreach ( array( 'x' => 'X', 'fb' => 'Facebook', 'ig' => 'Instagram', 'yt' => 'YouTube', 'li' => 'LinkedIn' ) as $k => $label ) {
		$u = get_theme_mod( 'cwt_social_' . $k );
		if ( $u ) {
			$out .= '<a href="' . esc_url( $u ) . '" rel="me noopener" target="_blank">' . esc_html( $label ) . '</a>';
		}
	}
	if ( $out ) {
		echo '<div class="social">' . $out . '</div>'; // phpcs:ignore
	}
}

/** Hero headline: each sentence on its own line, all in one colour. */
function cwt_hero() {
	$custom = trim( (string) get_theme_mod( 'cwt_headline', '' ) );
	$title  = $custom ? $custom : cwt_t( 'hero_title' );
	$lines  = preg_split( '/(?<=[\.\!\?。।])\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );
	$sub    = trim( (string) get_theme_mod( 'cwt_sub', '' ) );
	return array( 'lines' => $lines ? $lines : array( $title ), 'sub' => $sub, 'custom' => (bool) $custom );
}

/** Intro + long text + FAQ for a category (all editable in Calculators → Categories). */
function cwt_term_content( $term, $part ) {
	$v = get_term_meta( $term->term_id, 'cw_' . $part, true );
	return is_string( $v ) ? trim( $v ) : '';
}

/** FAQ accordion from pairs. */
function cwt_faq_html( $pairs, $open_first = true ) {
	if ( ! $pairs ) {
		return '';
	}
	$h = '<div class="faq">';
	foreach ( $pairs as $i => $qa ) {
		$h .= '<details' . ( $open_first && 0 === $i ? ' open' : '' ) . '><summary>' . esc_html( $qa[0] ) . '</summary><div class="ans"><p>' . wp_kses_post( $qa[1] ) . '</p></div></details>';
	}
	return $h . '</div>';
}

/** Term permalinks keyed "section/group" for the "all tools" pages (one pass, cached for the request). */
function cwt_group_links() {
	static $map = null;
	if ( null === $map ) {
		$map   = array();
		$terms = get_terms( array( 'taxonomy' => 'calc_category', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			$by = array();
			foreach ( $terms as $t ) {
				$by[ $t->term_id ] = $t;
			}
			foreach ( $terms as $t ) {
				$link = get_term_link( $t );
				if ( is_wp_error( $link ) ) {
					continue;
				}
				if ( $t->parent && isset( $by[ $t->parent ] ) ) {
					$map[ $by[ $t->parent ]->slug . '/' . html_entity_decode( $t->name, ENT_QUOTES ) ] = $link;
				} else {
					$map[ $t->slug ] = $link;
				}
			}
		}
	}
	return $map;
}

/**
 * Every published tool grouped Section → Group, built from the cached search index (cheap).
 *
 * @param string $kind 'calc' = everything that is not a converter, 'conv' = converters.
 * @return array Section slug => array( 'term' => WP_Term, 'groups' => array( name => array( tools ) ) )
 */
function cwt_all_tools( $kind ) {
	if ( ! function_exists( 'cw_search_index' ) ) {
		return array();
	}
	$by = array();
	foreach ( cw_search_index() as $it ) {
		$is_conv = ! empty( $it['v'] );
		if ( ( 'conv' === $kind ) !== $is_conv ) {
			continue;
		}
		$by[ $it['c'] ][ $it['g'] ? $it['g'] : '—' ][] = $it;
	}
	$out = array();
	foreach ( cwt_sections() as $s ) {
		if ( ! empty( $by[ $s->slug ] ) ) {
			// Sub-categories in the order set in Calculators → Categories; the tools people use most first, then A to Z.
			$groups = array();
			foreach ( cwt_subs( $s->term_id ) as $g ) {
				$gn = html_entity_decode( $g->name, ENT_QUOTES );
				if ( isset( $by[ $s->slug ][ $gn ] ) ) {
					$groups[ $gn ] = $by[ $s->slug ][ $gn ];
				}
			}
			foreach ( $by[ $s->slug ] as $gn => $tools ) {
				if ( ! isset( $groups[ $gn ] ) ) {
					$groups[ $gn ] = $tools;
				}
			}
			foreach ( $groups as $gn => &$tools ) {
				usort(
					$tools,
					function ( $a, $b ) {
						$pa = ! empty( $a['p'] ) ? 0 : 1;
						$pb = ! empty( $b['p'] ) ? 0 : 1;
						return $pa === $pb ? strcasecmp( $a['t'], $b['t'] ) : $pa - $pb;
					}
				);
			}
			unset( $tools );
			$out[ $s->slug ] = array( 'term' => $s, 'groups' => $groups );
		}
	}
	if ( 'conv' === $kind ) {
		// Most converters first: the unit and currency converters lead, the one-off ones follow.
		$size = function ( $sec ) {
			$n = 0;
			foreach ( $sec['groups'] as $g ) {
				$n += count( $g );
			}
			return $n;
		};
		uasort( $out, function ( $a, $b ) use ( $size ) {
			return $size( $b ) - $size( $a );
		} );
	}
	return $out;
}

/** Fallback menu when no menu is assigned to "Main menu". */
function cwt_auto_menu( $class = 'nav-list' ) {
	$rows = array(
		array( 'all-calculators', 'calculators', 'Calculators' ),
		array( 'all-converters', 'converters', 'Converters' ),
		array( 'categories', 'categories', 'Categories' ),
		array( 'popular', 'popular', 'Popular' ),
		array( 'blog', 'blog', 'Blog' ),
		array( 'about', 'about', 'About' ),
	);
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( $rows as $r ) {
		$pid = function_exists( 'cw_page_id' ) ? cw_page_id( $r[0] ) : 0;
		if ( $pid ) {
			echo '<li class="' . ( is_page( $pid ) || ( 'blog' === $r[0] && ( is_home() || is_singular( 'post' ) ) ) ? 'current-menu-item' : '' ) . '"><a href="' . esc_url( get_permalink( $pid ) ) . '" ' . cwt_di( $r[1] ) . '>' . esc_html( function_exists( 'cw_t' ) ? cwt_t( $r[1] ) : $r[2] ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
	echo '</ul>';
}

/** Extra links shown at the bottom of the phone menu: pages that are not in the main bar. */
function cwt_nav_more() {
	$rows = array( 'how-it-works' => 'how_it_works', 'privacy-policy' => 'privacy', 'terms' => 'terms', 'disclaimer' => 'disclaimer' );
	echo '<div class="nav-more">';
	foreach ( $rows as $slug => $key ) {
		$pid = function_exists( 'cw_page_id' ) ? cw_page_id( $slug ) : 0;
		if ( $pid ) {
			echo '<a href="' . esc_url( get_permalink( $pid ) ) . '" ' . cwt_di( $key ) . '>' . esc_html( get_the_title( $pid ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
	echo '</div>';
}

/** Blog post card: date, title, short excerpt. A featured image shows on top; without one the card shows a category icon. */
function cwt_post_card( $post ) {
	$post = get_post( $post );
	$has  = has_post_thumbnail( $post );
	echo '<a class="post" href="' . esc_url( get_permalink( $post ) ) . '">';
	if ( $has ) {
		echo '<span class="thumb">' . get_the_post_thumbnail( $post, 'cwt-card', array( 'loading' => 'lazy', 'alt' => '' ) ) . '</span>'; // phpcs:ignore
	}
	echo '<span class="pb">' . ( $has ? '' : cwt_tile( 'c', cwt_post_art_slug( $post ), 52, 'post-i' ) ) . '<small>' . esc_html( get_the_date( '', $post ) ) . '</small><strong>' . esc_html( get_the_title( $post ) ) . '</strong><span class="ex">' . esc_html( wp_trim_words( get_the_excerpt( $post ), 24, '…' ) ) . '</span></span></a>'; // phpcs:ignore
}
