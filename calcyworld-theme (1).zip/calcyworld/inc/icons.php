<?php
/**
 * Icons: the plugin's 112-icon set for categories and tools, plus the theme's own interface icons.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

/**
 * Inline SVG icon (stroke, inherits colour). Looks in the interface set first, then in the Calcyworld Core set.
 *
 * @param string $name Icon name.
 * @param int    $size Pixels.
 * @return string
 */
function cwt_icon( $name, $size = 22 ) {
	$ui = array(
		'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
		'sun'    => '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/>',
		'moon'   => '<path d="M19.5 14.5A8 8 0 0 1 9.5 4.5a7.5 7.5 0 1 0 10 10z"/>',
		'globe'  => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h10"/>',
		'close'  => '<path d="M6 6l12 12M18 6 6 18"/>',
		'arrow'  => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'back'   => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
		'chev'   => '<path d="m9 6 6 6-6 6"/>',
		'down'   => '<path d="m6 9 6 6 6-6"/>',
		'share'  => '<circle cx="6" cy="12" r="2.4"/><circle cx="18" cy="6" r="2.4"/><circle cx="18" cy="18" r="2.4"/><path d="m8.1 10.9 7.8-3.8M8.1 13.1l7.8 3.8"/>',
		'info'   => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
		'check'  => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
		'trend'  => '<path d="M4 17l5-5 4 4 7-8"/><path d="M15 8h5v5"/>',
		'bolt'   => '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
		'tiles'  => '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/>',
	);
	if ( isset( $ui[ $name ] ) ) {
		return '<svg class="ico ico-' . esc_attr( $name ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $ui[ $name ] . '</svg>';
	}
	if ( function_exists( 'cw_icon' ) ) {
		return cw_icon( $name ? $name : 'grid', $size, 'ico' );
	}
	return cwt_icon( 'info', $size );
}

/** Brand mark: a calculator keypad on the accent colour. */
function cwt_mark( $size = 38 ) {
	return '<span class="mark" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px"><svg width="' . (int) round( $size * .62 ) . '" height="' . (int) round( $size * .62 ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="3.5"/><path d="M8 7.5h8"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/></svg></span>';
}
