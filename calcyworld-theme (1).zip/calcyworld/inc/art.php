<?php
/**
 * Icons. Categories have small two-tone drawings (one hue, tinted fill + accent line); tools use the Calcyworld Core
 * line-icon set. Both are drawn once per page in a hidden sprite and reused with <use>. Colours follow day / night mode
 * and the accent colour chosen in the Customizer.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

/** All category icons: key => inner SVG markup (viewBox 0 0 48 48). */
function cwt_ci_all() {
	static $a = null;
	if ( null === $a ) {
		$a = require get_template_directory() . '/inc/icon-data.php';
	}
	return $a;
}

/**
 * A category icon as inline SVG. Pass a section slug (finance, health…) or one of grid, star, book, search, compass.
 * Unknown slugs fall back to "math".
 *
 * @param string $slug  Section slug.
 * @param int    $size  Pixels.
 * @param string $class Extra class on the <svg>.
 * @return string
 */
function cwt_ci( $slug, $size = 28, $class = '' ) {
	$all  = cwt_ci_all();
	$slug = isset( $all[ $slug ] ) ? $slug : 'math';
	return '<svg class="ci' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><use href="#ci-' . esc_attr( $slug ) . '"/></svg>';
}

/**
 * A tool icon (line icon from the Core plugin set) as inline SVG.
 *
 * @param string $name  Icon name from the plugin set (coins, ruler, percent…).
 * @param int    $size  Pixels.
 * @param string $class Extra class.
 * @return string
 */
function cwt_ti( $name, $size = 22, $class = '' ) {
	$set  = function_exists( 'cw_data' ) ? cw_data( 'icons' ) : array();
	$name = isset( $set[ $name ] ) ? $name : 'grid';
	return '<svg class="ti' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#ti-' . esc_attr( $name ) . '"/></svg>';
}

/** A rounded tile that holds a category icon (kind "c") or a tool icon (kind "t"). $size is the tile size in pixels. */
function cwt_tile( $kind, $key, $size = 48, $class = '' ) {
	$in = (int) round( $size * .62 );
	return '<span class="itile' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" style="--ts:' . (int) $size . 'px">' . ( 'c' === $kind ? cwt_ci( $key, $in ) : cwt_ti( $key, $in ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/** The icon name of a tool post (the line icon chosen for it; "calc" when none). */
function cwt_post_icon( $post ) {
	$post = get_post( $post );
	if ( $post && function_exists( 'cw_tool_icon' ) ) {
		return cw_tool_icon( $post->ID );
	}
	$ic = $post ? get_post_meta( $post->ID, '_cw_icon', true ) : '';
	return $ic ? $ic : 'calc';
}

/** Print the sprite once (footer). */
function cwt_icon_sprite() {
	echo '<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>';
	foreach ( cwt_ci_all() as $slug => $inner ) {
		echo '<symbol id="ci-' . esc_attr( $slug ) . '" viewBox="0 0 48 48">' . $inner . '</symbol>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( function_exists( 'cw_data' ) ) {
		foreach ( (array) cw_data( 'icons' ) as $name => $inner ) {
			echo '<symbol id="ti-' . esc_attr( $name ) . '" viewBox="0 0 24 24">' . $inner . '</symbol>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
	echo '</defs></svg>';
}
add_action( 'wp_footer', 'cwt_icon_sprite', 5 );

/** Which icon a blog post card uses: the `_cw_art` custom field if set (a category slug), else a stable pick by post ID. */
function cwt_post_art_slug( $post ) {
	$post = get_post( $post );
	$set  = $post ? get_post_meta( $post->ID, '_cw_art', true ) : '';
	$all  = array_values( array_diff( array_keys( cwt_ci_all() ), array( 'grid', 'star', 'book', 'search', 'compass' ) ) );
	if ( $set && in_array( $set, $all, true ) ) {
		return $set;
	}
	return $all[ $post ? $post->ID % count( $all ) : 0 ];
}
