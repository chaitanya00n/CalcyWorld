<?php
/**
 * Appearance → Customize → Calcyworld: colours, home page text, footer, credits, social links.
 * (Ads are managed in Calcyworld → Ads.)
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

/** Defaults in one place. Empty text = use the built-in, translated wording. */
function cwt_defaults() {
	return array(
		'cwt_look'        => 'classic',
		'cwt_accent'      => '#5242E6',
		'cwt_mode'        => 'auto',
		'cwt_font'        => 1,
		'cwt_brand'       => 'Calcyworld',
		'cwt_headline'    => '',
		'cwt_sub'         => '',
		'cwt_search_ph'   => '',
		'cwt_show_stats'  => 1,
		'cwt_show_rates'  => 1,
		'cwt_show_blog'   => 1,
		'cwt_about'       => 'Free calculators and converters for money, health, maths and everyday life — in your currency and language.',
		'cwt_copyright'   => '© {year} Calcyworld. Created by Rezoic.',
		'cwt_credit_text' => 'REZOIC',
		'cwt_credit_url'  => '',
		'cwt_disclaimer'  => 'Calculators give estimates for general information. They are not financial, tax, legal or medical advice.',
		'cwt_social_x'    => '',
		'cwt_social_fb'   => '',
		'cwt_social_ig'   => '',
		'cwt_social_yt'   => '',
		'cwt_social_li'   => '',
	);
}

function cwt_mod( $key ) {
	$d = cwt_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

/** True when the visitor sees the Soft design (Appearance → Customize → Calcyworld → Colours & style). */
function cwt_is_soft() {
	return 'soft' === apply_filters( 'cwt_look', cwt_mod( 'cwt_look' ) );
}

/** Text mod with {year} replaced. */
function cwt_text( $key ) {
	return str_replace( '{year}', wp_date( 'Y' ), cwt_mod( $key ) );
}

add_action(
	'customize_register',
	function ( $wp ) {
		$d = cwt_defaults();
		$wp->add_panel( 'cwt', array( 'title' => __( 'Calcyworld', 'calcyworld' ), 'priority' => 20 ) );

		/* Colours & style */
		$wp->add_section( 'cwt_style', array( 'title' => __( 'Colours & style', 'calcyworld' ), 'panel' => 'cwt' ) );
		$wp->add_setting( 'cwt_look', array( 'default' => 'classic', 'sanitize_callback' => function ( $v ) { return in_array( $v, array( 'classic', 'soft' ), true ) ? $v : 'classic'; } ) );
		$wp->add_control( 'cwt_look', array( 'label' => __( 'Design style', 'calcyworld' ), 'description' => __( 'Classic: flat cards. Soft: layered rounded panels, soft shadows, black icon tiles. The layout, fonts and every page text stay exactly the same.', 'calcyworld' ), 'section' => 'cwt_style', 'type' => 'radio', 'choices' => array( 'classic' => __( 'Classic', 'calcyworld' ), 'soft' => __( 'Soft (layered, rounded)', 'calcyworld' ) ) ) );
		$wp->add_setting( 'cwt_accent', array( 'default' => $d['cwt_accent'], 'sanitize_callback' => 'sanitize_hex_color' ) );
		$wp->add_control( new WP_Customize_Color_Control( $wp, 'cwt_accent', array( 'label' => __( 'Accent colour (buttons, links, highlights)', 'calcyworld' ), 'section' => 'cwt_style' ) ) );
		$wp->add_setting( 'cwt_mode', array( 'default' => 'auto', 'sanitize_callback' => function ( $v ) { return in_array( $v, array( 'auto', 'light', 'dark' ), true ) ? $v : 'auto'; } ) );
		$wp->add_control( 'cwt_mode', array( 'label' => __( 'Default day / night mode', 'calcyworld' ), 'section' => 'cwt_style', 'type' => 'select', 'choices' => array( 'auto' => __( 'Follow the visitor’s device', 'calcyworld' ), 'light' => __( 'Day', 'calcyworld' ), 'dark' => __( 'Night', 'calcyworld' ) ) ) );
		$wp->add_setting( 'cwt_font', array( 'default' => 1, 'sanitize_callback' => 'absint' ) );
		$wp->add_control( 'cwt_font', array( 'label' => __( 'Load the Bricolage Grotesque and Manrope fonts from Google Fonts (turn off for strict privacy / GDPR setups)', 'calcyworld' ), 'section' => 'cwt_style', 'type' => 'checkbox' ) );

		/* Home page */
		$wp->add_section( 'cwt_home', array( 'title' => __( 'Home page', 'calcyworld' ), 'panel' => 'cwt', 'description' => __( 'Leave the text boxes empty to use the built-in wording, which is translated into 10 languages automatically. Typing your own text replaces it in every language.', 'calcyworld' ) ) );
		$text = array(
			'cwt_headline'  => array( __( 'Headline (two sentences look best)', 'calcyworld' ), 'text' ),
			'cwt_sub'       => array( __( 'Intro text', 'calcyworld' ), 'textarea' ),
			'cwt_search_ph' => array( __( 'Search box placeholder', 'calcyworld' ), 'text' ),
		);
		foreach ( $text as $k => $c ) {
			$wp->add_setting( $k, array( 'default' => '', 'sanitize_callback' => 'textarea' === $c[1] ? 'sanitize_textarea_field' : 'sanitize_text_field' ) );
			$wp->add_control( $k, array( 'label' => $c[0], 'section' => 'cwt_home', 'type' => $c[1] ) );
		}
		foreach ( array(
			'cwt_show_stats' => __( 'Show the numbers strip (tools, categories, currencies, languages)', 'calcyworld' ),
			'cwt_show_rates' => __( 'Show the live currency rates panel', 'calcyworld' ),
			'cwt_show_blog'  => __( 'Show latest blog articles', 'calcyworld' ),
		) as $k => $label ) {
			$wp->add_setting( $k, array( 'default' => 1, 'sanitize_callback' => 'absint' ) );
			$wp->add_control( $k, array( 'label' => $label, 'section' => 'cwt_home', 'type' => 'checkbox' ) );
		}

		/* Footer & credits */
		$wp->add_section( 'cwt_footer', array( 'title' => __( 'Footer & credits', 'calcyworld' ), 'panel' => 'cwt' ) );
		foreach ( array(
			'cwt_brand'       => array( __( 'Brand name (header & footer)', 'calcyworld' ), 'text' ),
			'cwt_about'       => array( __( 'About text', 'calcyworld' ), 'textarea' ),
			'cwt_copyright'   => array( __( 'Copyright line ({year} becomes the current year)', 'calcyworld' ), 'text' ),
			'cwt_credit_text' => array( __( '“Powered by” name', 'calcyworld' ), 'text' ),
			'cwt_credit_url'  => array( __( '“Powered by” link (optional)', 'calcyworld' ), 'url' ),
			'cwt_disclaimer'  => array( __( 'Disclaimer', 'calcyworld' ), 'textarea' ),
		) as $k => $c ) {
			$wp->add_setting( $k, array( 'default' => $d[ $k ], 'sanitize_callback' => 'url' === $c[1] ? 'esc_url_raw' : 'sanitize_textarea_field' ) );
			$wp->add_control( $k, array( 'label' => $c[0], 'section' => 'cwt_footer', 'type' => $c[1] ) );
		}
		foreach ( array( 'x' => 'X / Twitter', 'fb' => 'Facebook', 'ig' => 'Instagram', 'yt' => 'YouTube', 'li' => 'LinkedIn' ) as $k => $label ) {
			$wp->add_setting( 'cwt_social_' . $k, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
			$wp->add_control( 'cwt_social_' . $k, array( 'label' => $label . ' URL', 'section' => 'cwt_footer', 'type' => 'url' ) );
		}
	}
);

/** Hex → mixed with another colour. */
function cwt_hex_mix( $hex, $with, $amount ) {
	$a = sscanf( ltrim( $hex, '#' ), '%02x%02x%02x' );
	$b = sscanf( ltrim( $with, '#' ), '%02x%02x%02x' );
	if ( ! $a || count( $a ) < 3 || ! $b || count( $b ) < 3 ) {
		return $hex;
	}
	$o = array();
	for ( $i = 0; $i < 3; $i++ ) {
		$o[] = (int) round( $a[ $i ] * ( 1 - $amount ) + $b[ $i ] * $amount );
	}
	return vsprintf( '#%02x%02x%02x', $o );
}

/** CSS variables from the Customizer accent colour (buttons, links, highlights and the illustrations all follow it). */
function cwt_custom_css() {
	$acc = sanitize_hex_color( cwt_mod( 'cwt_accent' ) );
	if ( ! $acc || '#5242e6' === strtolower( $acc ) ) {
		return '';
	}
	$dk = cwt_hex_mix( $acc, '#ffffff', .22 );
	return ':root{--acc:' . $acc . ';--acc-t:' . cwt_hex_mix( $acc, '#000000', .12 ) . ';--acc-h:' . cwt_hex_mix( $acc, '#000000', .16 ) . ';--acc-s:' . cwt_hex_mix( $acc, '#ffffff', .88 ) . ';--a4:' . $acc . ';--a3:' . cwt_hex_mix( $acc, '#ffffff', .38 ) . ';--a2:' . cwt_hex_mix( $acc, '#ffffff', .62 ) . ';--a1:' . cwt_hex_mix( $acc, '#ffffff', .8 ) . ';--a0:' . cwt_hex_mix( $acc, '#ffffff', .9 ) . '}'
		. 'html[data-theme=dark]{--acc:' . $dk . ';--acc-t:' . cwt_hex_mix( $acc, '#ffffff', .5 ) . ';--acc-h:' . cwt_hex_mix( $acc, '#ffffff', .36 ) . ';--acc-s:' . cwt_hex_mix( $acc, '#0D0F1F', .78 ) . ';--a4:' . cwt_hex_mix( $acc, '#ffffff', .45 ) . ';--a3:' . cwt_hex_mix( $acc, '#ffffff', .12 ) . ';--a2:' . cwt_hex_mix( $acc, '#0D0F1F', .45 ) . ';--a1:' . cwt_hex_mix( $acc, '#0D0F1F', .68 ) . ';--a0:' . cwt_hex_mix( $acc, '#0D0F1F', .8 ) . '}';
}
