<?php
/**
 * Shared body of the "All Calculators" and "All Converters" pages. Expects $cwt_kind = 'calc' | 'conv'.
 * Every section is a band with its picture; under it every sub-category lists every tool.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();

$all   = cwt_all_tools( $cwt_kind );
$links = cwt_group_links();
$total = 0;
foreach ( $all as $s ) {
	foreach ( $s['groups'] as $g ) {
		$total += count( $g );
	}
}
$title_key = 'conv' === $cwt_kind ? 'all_converters' : 'all_calculators';
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>
	<header class="chero">
		<div class="chero-t">
			<h1 <?php echo cwt_di( $title_key ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( $title_key ) ); ?></h1>
			<p class="cat-meta"<?php echo cwt_dn( 'tools_n', $total ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( $total ) ) ) ); ?></p>
			<label class="cat-filter">
				<?php echo cwt_icon( 'search', 18 ); // phpcs:ignore ?>
				<input type="search" class="js-filter" data-ph="filter" placeholder="<?php echo esc_attr( cwt_t( 'filter' ) ); ?>" aria-label="<?php echo esc_attr( cwt_t( 'filter' ) ); ?>" autocomplete="off">
			</label>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', 'conv' === $cwt_kind ? 'converters' : 'math', 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>

	<?php cwt_ad( 'category_top' ); ?>

	<div class="all-layout">
		<nav class="all-index" aria-label="<?php esc_attr_e( 'On this page', 'calcyworld' ); ?>">
			<b <?php echo cwt_di( 'on_page' ); // phpcs:ignore ?>><?php cwt_e( 'on_page' ); ?></b>
			<?php foreach ( $all as $slug => $s ) : $n = 0; foreach ( $s['groups'] as $g ) { $n += count( $g ); } ?>
				<a href="#sec-<?php echo esc_attr( $slug ); ?>"><span<?php echo cwt_term_di( $s['term'] ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s['term'] ) ); ?></span><small><?php echo (int) $n; ?></small></a>
			<?php endforeach; ?>
		</nav>

		<div class="alltools js-filter-all">
			<?php foreach ( $all as $slug => $s ) : $term = $s['term']; $n = 0; foreach ( $s['groups'] as $g ) { $n += count( $g ); } ?>
				<section class="as-sec" id="sec-<?php echo esc_attr( $slug ); ?>">
					<div class="as-head">
						<div class="as-ht">
							<h2><a href="<?php echo esc_url( get_term_link( $term ) ); ?>"<?php echo cwt_term_di( $term ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $term ) ); ?></a></h2>
							<p><span<?php echo cwt_dn( 'tools_n', $n ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( $n ) ) ) ); ?></span> · <a href="<?php echo esc_url( get_term_link( $term ) ); ?>" <?php echo cwt_di( 'view_all' ); // phpcs:ignore ?>><?php cwt_e( 'view_all' ); ?></a></p>
						</div>
						<div class="as-ha"><?php echo cwt_tile( 'c', $slug, 64, 'on-dark' ); // phpcs:ignore ?></div>
					</div>
					<div class="as-groups">
						<?php foreach ( $s['groups'] as $gname => $tools ) :
							$glink = isset( $links[ $slug . '/' . $gname ] ) ? $links[ $slug . '/' . $gname ] : ''; ?>
							<div class="as-g">
								<h3><?php if ( $glink ) : ?><a href="<?php echo esc_url( $glink ); ?>"><?php echo esc_html( $gname ); ?></a><?php else : echo esc_html( $gname ); endif; ?> <small><?php echo count( $tools ); ?></small></h3>
								<ul>
									<?php foreach ( $tools as $it ) : ?>
										<li><a href="<?php echo esc_url( $it['u'] ); ?>"><?php echo esc_html( $it['t'] ); ?></a></li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endforeach; ?>
					</div>
				</section>
			<?php endforeach; ?>
			<p class="empty js-empty" hidden <?php echo cwt_di( 'no_results' ); // phpcs:ignore ?>><?php cwt_e( 'no_results' ); ?></p>
		</div>
	</div>

	<?php
	while ( have_posts() ) :
		the_post();
		if ( trim( get_the_content() ) ) {
			echo '<section class="block-s"><div class="prose">';
			the_content();
			echo '</div></section>';
		}
	endwhile;
	?>
</div>
<?php
get_footer();
