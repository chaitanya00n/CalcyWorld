<?php
/**
 * Template Name: All Categories
 *
 * The 20 categories as illustrated cards, with their sub-categories listed.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
$sections = cwt_sections();
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>
	<header class="chero">
		<div class="chero-t">
			<h1 <?php echo cwt_di( 'categories' ); // phpcs:ignore ?>><?php cwt_e( 'categories' ); ?></h1>
			<?php
			while ( have_posts() ) :
				the_post();
				if ( trim( get_the_content() ) ) {
					echo '<div class="chero-p">' . wp_kses_post( wpautop( get_the_content() ) ) . '</div>'; // phpcs:ignore
				}
			endwhile;
			?>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', 'grid', 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>
	<ul class="ccards">
		<?php foreach ( $sections as $s ) : $subs = cwt_subs( $s->term_id ); $teaser = array(); foreach ( array_slice( $subs, 0, 4 ) as $t ) { $teaser[] = cwt_term_name( $t ); } ?>
			<li><a class="ccard" href="<?php echo esc_url( get_term_link( $s ) ); ?>">
				<?php echo cwt_tile( 'c', $s->slug, 56, 'cc-i' ); // phpcs:ignore ?>
				<span class="cc-b"><strong<?php echo cwt_term_di( $s ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></strong><span class="cc-n"<?php echo cwt_dn( 'tools_n', cwt_count( $s ) ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( cwt_count( $s ) ) ) ) ); ?></span><span class="cc-s"><?php echo esc_html( implode( ', ', $teaser ) ); ?></span></span>
			</a></li>
		<?php endforeach; ?>
	</ul>
</div>
<?php
get_footer();
