<?php
/**
 * A blog article.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$has_side = is_active_sidebar( 'blog-sidebar' ) || ( function_exists( 'cw_ad_html' ) && cw_ad_html( 'sidebar' ) );
	?>
	<article <?php post_class( 'wrap article' ); ?>>
		<?php cwt_breadcrumbs(); ?>
		<header class="art-head">
			<?php if ( ! has_post_thumbnail() ) { echo cwt_tile( 'c', cwt_post_art_slug( get_post() ), 60, 'art-i' ); } // phpcs:ignore ?>
			<h1><?php the_title(); ?></h1>
			<p class="meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> <span class="by"><?php the_author(); ?></span></p>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="art-img"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager' ) ); ?></div>
			<?php endif; ?>
		</header>
		<div class="art-grid<?php echo $has_side ? ' has-side' : ''; ?>">
			<div class="prose"><?php the_content(); wp_link_pages(); ?></div>
			<?php if ( $has_side ) : ?>
				<aside class="more-side"><?php cwt_ad( 'sidebar' ); dynamic_sidebar( 'blog-sidebar' ); ?></aside>
			<?php endif; ?>
		</div>
		<?php
		if ( comments_open() || get_comments_number() ) {
			echo '<div class="prose comments">';
			comments_template();
			echo '</div>';
		}
		?>
	</article>
	<?php
endwhile;
get_footer();
