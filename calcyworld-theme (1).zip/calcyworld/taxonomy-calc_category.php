<?php
/**
 * Category pages. Every section (Finance…) and every sub-category (Loans & EMI…) is its own page with
 * its own SEO title, description, intro, long text and FAQ — all editable in Calculators → Categories.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();

$term     = get_queried_object();
$is_group = (bool) $term->parent;
$section  = $is_group ? get_term( $term->parent, 'calc_category' ) : $term;
$intro    = cwt_term_content( $term, 'intro' );
$body     = cwt_term_content( $term, 'body' );
$faq      = function_exists( 'cw_parse_faq' ) ? cw_parse_faq( cwt_term_content( $term, 'faq' ) ) : array();
$subs     = $is_group ? cwt_subs( $section->term_id ) : cwt_subs( $term->term_id );
if ( ! $intro ) {
	$intro = wp_strip_all_tags( term_description( $term->term_id, 'calc_category' ) );
}
$n_tools = cwt_count( $term );
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>

	<header class="chero">
		<div class="chero-t">
			<h1<?php echo cwt_term_di( $term ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $term ) ); ?></h1>
			<?php if ( $intro ) : ?><p><?php echo esc_html( $intro ); ?></p><?php endif; ?>
			<p class="cat-meta">
				<?php if ( ! $is_group && $subs ) : ?><span<?php echo cwt_dn( 'n_subcats', count( $subs ) ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'n_subcats', array( 'n' => count( $subs ) ) ) ); ?></span> · <?php endif; ?>
				<span<?php echo cwt_dn( 'tools_n', $n_tools ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( $n_tools ) ) ) ); ?></span>
			</p>
			<label class="cat-filter">
				<?php echo cwt_icon( 'search', 18 ); // phpcs:ignore ?>
				<input type="search" class="js-filter" data-ph="filter" placeholder="<?php echo esc_attr( cwt_t( 'filter' ) ); ?>" aria-label="<?php echo esc_attr( cwt_t( 'filter' ) ); ?>" autocomplete="off">
			</label>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', $section->slug, 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>

	<?php cwt_ad( 'category_top' ); ?>

	<?php if ( $is_group ) : ?>
		<?php if ( count( $subs ) > 1 ) : ?>
			<nav class="pills" aria-label="<?php esc_attr_e( 'Sub-categories', 'calcyworld' ); ?>">
				<?php foreach ( $subs as $s ) : ?>
					<a class="pill-link<?php echo (int) $s->term_id === (int) $term->term_id ? ' is-on' : ''; ?>" href="<?php echo esc_url( get_term_link( $s ) ); ?>"<?php echo (int) $s->term_id === (int) $term->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></a>
				<?php endforeach; ?>
			</nav>
		<?php endif; ?>

		<?php if ( have_posts() ) : $i = 0; ?>
			<ul class="tgrid js-filter-list">
				<?php
				while ( have_posts() ) :
					the_post();
					cwt_card( get_post() );
					++$i;
					if ( 12 === $i ) {
						ob_start();
						cwt_ad( 'category_middle' );
						$ad = ob_get_clean();
						if ( $ad ) {
							echo '<li class="ad-li">' . $ad . '</li>'; // phpcs:ignore
						}
					}
				endwhile;
				?>
			</ul>
			<p class="empty js-empty" hidden <?php echo cwt_di( 'no_results' ); // phpcs:ignore ?>><?php cwt_e( 'no_results' ); ?></p>
			<div class="pager"><?php the_posts_pagination(); ?></div>
		<?php else : ?>
			<p class="empty"><?php cwt_e( 'no_results' ); ?></p>
		<?php endif; ?>
	<?php else : ?>
		<?php if ( $subs ) : ?>
			<ul class="subgrid big js-filter-list">
				<?php foreach ( $subs as $t ) : ?>
					<li><a class="tool sub" href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo cwt_tile( 'c', $section->slug, 40 ); // phpcs:ignore ?><span class="t"><?php echo esc_html( cwt_term_name( $t ) ); ?><small<?php echo cwt_dn( 'tools_n', cwt_count( $t ) ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( cwt_count( $t ) ) ) ) ); ?></small></span><?php echo cwt_icon( 'chev', 16 ); // phpcs:ignore ?></a></li>
				<?php endforeach; ?>
			</ul>
			<p class="empty js-empty" hidden <?php echo cwt_di( 'no_results' ); // phpcs:ignore ?>><?php cwt_e( 'no_results' ); ?></p>
		<?php endif; ?>

		<?php cwt_ad( 'category_middle' ); ?>

		<?php
		$top = cwt_calcs_in( $term->term_id, 12, true, true );
		if ( $top ) :
			?>
			<section class="block-s">
				<div class="block-h"><h2 <?php echo cwt_di( 'top_tools' ); // phpcs:ignore ?>><?php cwt_e( 'top_tools' ); ?></h2></div>
				<ul class="tgrid">
					<?php foreach ( $top as $p ) { cwt_card( $p ); } ?>
				</ul>
			</section>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( $body ) : ?>
		<section class="block-s"><div class="prose"><?php echo wp_kses_post( wpautop( $body ) ); ?></div></section>
	<?php endif; ?>

	<?php if ( $faq ) : ?>
		<section class="block-s">
			<div class="block-h"><h2 <?php echo cwt_di( 'faq' ); // phpcs:ignore ?>><?php cwt_e( 'faq' ); ?></h2></div>
			<?php echo cwt_faq_html( $faq ); // phpcs:ignore ?>
		</section>
	<?php endif; ?>

	<?php if ( $is_group && $subs && count( $subs ) > 1 ) : ?>
		<section class="block-s">
			<div class="block-h"><h2><span <?php echo cwt_di( 'more_in' ); // phpcs:ignore ?>><?php cwt_e( 'more_in' ); ?></span> <a href="<?php echo esc_url( get_term_link( $section ) ); ?>"<?php echo cwt_term_di( $section ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $section ) ); ?></a></h2></div>
			<ul class="subgrid">
				<?php foreach ( $subs as $t ) : if ( (int) $t->term_id === (int) $term->term_id ) { continue; } ?>
					<li><a class="tool sub" href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo cwt_tile( 'c', $section->slug, 40 ); // phpcs:ignore ?><span class="t"><?php echo esc_html( cwt_term_name( $t ) ); ?><small<?php echo cwt_dn( 'tools_n', cwt_count( $t ) ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( cwt_count( $t ) ) ) ) ); ?></small></span><?php echo cwt_icon( 'chev', 16 ); // phpcs:ignore ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>
</div>
<?php
get_footer();
