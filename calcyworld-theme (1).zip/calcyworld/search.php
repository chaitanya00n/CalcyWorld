<?php
/**
 * Search results. (The plugin sends visitors straight to a tool when one clearly matches; this page is for everything else.)
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
global $wp_query;
get_header();
$q = get_search_query();
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>
	<header class="chero">
		<div class="chero-t">
			<h1><?php echo esc_html( sprintf( cwt_t( 'results_for' ), $q ) ); ?></h1>
			<p class="cat-meta"><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( (int) $wp_query->found_posts ) ) ) ); ?></p>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', 'search', 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>
	<?php if ( have_posts() ) : ?>
		<ul class="tgrid">
			<?php
			while ( have_posts() ) :
				the_post();
				if ( 'calculator' === get_post_type() ) {
					cwt_card( get_post() );
				} else {
					echo '<li><a class="tool" href="' . esc_url( get_permalink() ) . '">' . cwt_tile( 'c', 'book', 40 ) . '<span class="t">' . esc_html( get_the_title() ) . '</span>' . cwt_icon( 'chev', 16 ) . '</a></li>'; // phpcs:ignore
				}
			endwhile;
			?>
		</ul>
		<div class="pager"><?php the_posts_pagination(); ?></div>
	<?php else : ?>
		<div class="nf-box">
			<p class="empty"><?php cwt_e( 'no_results' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	<?php endif; ?>
</div>
<?php
get_footer();
