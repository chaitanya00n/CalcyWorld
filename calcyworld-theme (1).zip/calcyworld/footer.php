<?php
/**
 * Site footer, search palette and country picker dialogs.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

$cwt_credit_url  = cwt_mod( 'cwt_credit_url' );
$cwt_credit_text = cwt_mod( 'cwt_credit_text' );
$cwt_pg          = function ( $slug ) {
	return function_exists( 'cw_page_id' ) ? cw_page_id( $slug ) : 0;
};
?>
</main>
<?php cwt_ad( 'footer' ); ?>
<footer class="site-footer">
	<div class="wrap">
		<div class="foot">
			<div class="foot-brand">
				<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo cwt_mark( 36 ); // phpcs:ignore ?><span class="brand-name"><?php echo esc_html( cwt_mod( 'cwt_brand' ) ); ?></span></a>
				<p><?php echo esc_html( cwt_mod( 'cwt_about' ) ); ?></p>
				<?php cwt_social(); ?>
			</div>
			<div class="foot-col">
				<h2 <?php echo cwt_di( 'calculators' ); // phpcs:ignore ?>><?php cwt_e( 'calculators' ); ?></h2>
				<ul>
					<?php
					foreach ( array( 'all-calculators' => 'all_calculators', 'all-converters' => 'all_converters', 'categories' => 'categories', 'popular' => 'popular' ) as $slug => $key ) {
						if ( $cwt_pg( $slug ) ) {
							echo '<li><a href="' . esc_url( get_permalink( $cwt_pg( $slug ) ) ) . '" ' . cwt_di( $key ) . '>' . esc_html( cwt_t( $key ) ) . '</a></li>'; // phpcs:ignore
						}
					}
					?>
				</ul>
			</div>
			<div class="foot-col">
				<h2><?php esc_html_e( 'Calcyworld', 'calcyworld' ); ?></h2>
				<?php
				if ( has_nav_menu( 'footer' ) ) {
					wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1 ) );
				} else {
					echo '<ul>';
					foreach ( array( 'about' => 'about', 'how-it-works' => 'how_it_works', 'blog' => 'blog' ) as $slug => $key ) {
						if ( $cwt_pg( $slug ) ) {
							echo '<li><a href="' . esc_url( get_permalink( $cwt_pg( $slug ) ) ) . '" ' . cwt_di( $key ) . '>' . esc_html( cwt_t( $key ) ) . '</a></li>'; // phpcs:ignore
						}
					}
					echo '</ul>';
				}
				?>
			</div>
			<div class="foot-col">
				<h2><?php esc_html_e( 'Legal', 'calcyworld' ); ?></h2>
				<?php
				if ( has_nav_menu( 'footer-2' ) ) {
					wp_nav_menu( array( 'theme_location' => 'footer-2', 'container' => false, 'depth' => 1 ) );
				} else {
					echo '<ul>';
					foreach ( array( 'privacy-policy' => 'privacy', 'terms' => 'terms', 'disclaimer' => 'disclaimer' ) as $slug => $key ) {
						if ( $cwt_pg( $slug ) ) {
							echo '<li><a href="' . esc_url( get_permalink( $cwt_pg( $slug ) ) ) . '" ' . cwt_di( $key ) . '>' . esc_html( cwt_t( $key ) ) . '</a></li>'; // phpcs:ignore
						}
					}
					echo '</ul>';
				}
				?>
			</div>
		</div>
		<div class="foot-bottom">
			<p><?php echo esc_html( cwt_text( 'cwt_copyright' ) ); ?></p>
			<p class="credit">
				<span <?php echo cwt_di( 'powered_by' ); // phpcs:ignore ?>><?php cwt_e( 'powered_by' ); ?></span>
				<?php if ( $cwt_credit_url ) : ?>
					<a class="credit-pill" href="<?php echo esc_url( $cwt_credit_url ); ?>" rel="noopener"><?php echo esc_html( $cwt_credit_text ); ?></a>
				<?php else : ?>
					<span class="credit-pill"><?php echo esc_html( $cwt_credit_text ); ?></span>
				<?php endif; ?>
			</p>
		</div>
		<p class="disclaimer"><?php echo esc_html( cwt_mod( 'cwt_disclaimer' ) ); ?></p>
	</div>
</footer>

<div class="palette" id="palette" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Search', 'calcyworld' ); ?>" hidden>
	<div class="palette-box">
		<form class="palette-form" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php echo cwt_icon( 'search', 20 ); // phpcs:ignore ?>
			<input type="search" name="s" class="js-palette-input" data-ph="search_ph" placeholder="<?php echo esc_attr( cwt_mod( 'cwt_search_ph' ) ? cwt_mod( 'cwt_search_ph' ) : cwt_t( 'search_ph' ) ); ?>" autocomplete="off" spellcheck="false" aria-controls="palette-list" aria-label="<?php esc_attr_e( 'Search', 'calcyworld' ); ?>">
			<button type="button" class="kbd js-close-palette">Esc</button>
		</form>
		<ul class="palette-list" id="palette-list" role="listbox"></ul>
	</div>
</div>

<div class="palette" id="country-dlg" role="dialog" aria-modal="true" aria-labelledby="country-title" hidden>
	<div class="palette-box">
		<div class="dlg-head"><h2 id="country-title"><span <?php echo cwt_di( 'country' ); // phpcs:ignore ?>><?php cwt_e( 'country' ); ?></span> &amp; <span <?php echo cwt_di( 'currency' ); // phpcs:ignore ?>><?php cwt_e( 'currency' ); ?></span></h2><button type="button" class="kbd js-close-country">Esc</button></div>
		<div class="palette-form"><?php echo cwt_icon( 'search', 20 ); // phpcs:ignore ?><input type="search" class="js-country-input" placeholder="<?php esc_attr_e( 'Search country or currency…', 'calcyworld' ); ?>" autocomplete="off"></div>
		<ul class="palette-list country-list js-country-list" role="listbox"></ul>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
