<?php
/**
 * Template Name: All Calculators
 *
 * Every calculator, grouped by category and sub-category, with a live filter.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
$cwt_kind = 'calc';
require get_template_directory() . '/template-parts/all-tools.php';
