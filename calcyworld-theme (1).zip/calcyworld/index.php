<?php
/**
 * Blog index (and the fallback for any list).
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
$cwt_title = is_home() && get_option( 'page_for_posts' ) ? get_the_title( get_option( 'page_for_posts' ) ) : ( is_archive() ? get_the_archive_title() : cwt_t( 'blog' ) );
?>
<div class="wrap cat-wrap">
	<?php cwt_breadcrumbs(); ?>
	<header class="chero">
		<div class="chero-t">
			<h1><?php echo esc_html( $cwt_title ); ?></h1>
			<p><?php echo esc_html( cwt_t( 'blog_sub' ) ); ?></p>
		</div>
		<div class="chero-a"><?php echo cwt_tile( 'c', 'book', 96, 'on-dark' ); // phpcs:ignore ?></div>
	</header>
	<?php if ( have_posts() ) : ?>
		<ul class="posts">
			<?php
			while ( have_posts() ) :
				the_post();
				echo '<li>';
				cwt_post_card( get_post() );
				echo '</li>';
			endwhile;
			?>
		</ul>
		<div class="pager"><?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?></div>
	<?php else : ?>
		<p class="empty"><?php cwt_e( 'no_results' ); ?></p>
	<?php endif; ?>
</div>
<?php
get_footer();
