<?php
/**
 * Site header: brand, main navigation, search, country and currency, language, day / night.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;

$cwt_lang      = function_exists( 'cw_ui_lang_config' ) ? cw_ui_lang_config() : array( 'enabled' => array( 'en' ), 'names' => array( 'en' => 'English' ), 'own' => true );
$cwt_show_lang = empty( $cwt_lang['own'] ) && count( $cwt_lang['enabled'] ) > 1;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#main" <?php echo cwt_di( 'skip' ); // phpcs:ignore ?>><?php cwt_e( 'skip' ); ?></a>

<header class="site-header" id="top">
	<div class="wrap">
		<div class="hdr">
			<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( cwt_mod( 'cwt_brand' ) ); ?>">
				<?php
				if ( has_custom_logo() ) {
					echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'custom-logo', 'alt' => cwt_mod( 'cwt_brand' ) ) ); // phpcs:ignore
				} else {
					echo cwt_mark( 38 ); // phpcs:ignore
					echo '<span class="brand-name">' . esc_html( cwt_mod( 'cwt_brand' ) ) . '</span>';
				}
				?>
			</a>

			<nav class="nav" id="site-nav" aria-label="<?php esc_attr_e( 'Main', 'calcyworld' ); ?>">
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'nav-list', 'depth' => 1 ) );
				} else {
					cwt_auto_menu();
				}
				cwt_nav_more();
				?>
			</nav>

			<div class="hdr-tools">
				<button class="ibtn js-open-search" type="button" aria-label="<?php esc_attr_e( 'Search', 'calcyworld' ); ?>"><?php echo cwt_icon( 'search', 20 ); // phpcs:ignore ?></button>
				<button class="chipb js-country" type="button" aria-label="<?php esc_attr_e( 'Change country and currency', 'calcyworld' ); ?>"><span class="js-country-flag" aria-hidden="true"><?php echo cwt_icon( 'globe', 18 ); // phpcs:ignore ?></span><span class="js-country-label">USD</span></button>
				<?php if ( $cwt_show_lang ) : ?>
					<div class="lang-wrap">
						<button class="chipb js-lang" type="button" aria-haspopup="true" aria-expanded="false" aria-label="<?php esc_attr_e( 'Language', 'calcyworld' ); ?>"><span class="js-lang-code">EN</span><?php echo cwt_icon( 'down', 14 ); // phpcs:ignore ?></button>
						<ul class="lang-menu" id="lang-menu" role="menu" hidden>
							<?php foreach ( $cwt_lang['names'] as $code => $name ) : ?>
								<li role="none"><button type="button" role="menuitem" data-lang="<?php echo esc_attr( $code ); ?>" lang="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $name ); ?></button></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<button class="ibtn js-theme" type="button" role="switch" aria-checked="false" aria-label="<?php esc_attr_e( 'Switch between day and night mode', 'calcyworld' ); ?>"><span class="t-sun"><?php echo cwt_icon( 'sun', 19 ); // phpcs:ignore ?></span><span class="t-moon"><?php echo cwt_icon( 'moon', 19 ); // phpcs:ignore ?></span></button>
				<button class="ibtn menu-btn js-menu" type="button" aria-expanded="false" aria-controls="site-nav" aria-label="<?php esc_attr_e( 'Menu', 'calcyworld' ); ?>"><span class="t-open"><?php echo cwt_icon( 'menu', 20 ); // phpcs:ignore ?></span><span class="t-close"><?php echo cwt_icon( 'close', 20 ); // phpcs:ignore ?></span></button>
			</div>
		</div>
	</div>
</header>
<?php cwt_ad( 'header' ); ?>
<main id="main" class="site-main" tabindex="-1">
