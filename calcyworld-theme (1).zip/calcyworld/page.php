<?php
/**
 * A normal page (About, Privacy…). Edit the text in Pages → the page; the SEO fields are in the box under the editor.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<article <?php post_class( 'wrap narrow article' ); ?>>
		<?php cwt_breadcrumbs(); ?>
		<header class="art-head"><h1><?php the_title(); ?></h1></header>
		<div class="prose"><?php the_content(); wp_link_pages(); ?></div>
	</article>
	<?php
endwhile;
get_footer();
