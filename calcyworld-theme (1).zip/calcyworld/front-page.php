<?php
/**
 * Home page: centred hero and search, numbers, popular in your country, illustrated categories, sub-category finder,
 * live rates, blog, and the home page's own text (edit it in Pages → Home).
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();

$hero     = cwt_hero();
$sections = cwt_sections();
$counts   = function_exists( 'wp_count_posts' ) ? wp_count_posts( 'calculator' ) : null;
$total    = $counts ? (int) $counts->publish : 0;
$ph       = cwt_mod( 'cwt_search_ph' ) ? cwt_mod( 'cwt_search_ph' ) : cwt_t( 'search_ph' );
$groups   = 0;
foreach ( $sections as $s ) {
	$groups += count( cwt_subs( $s->term_id ) );
}
$pid  = function ( $slug ) {
	return function_exists( 'cw_page_id' ) ? cw_page_id( $slug ) : 0;
};
$pop = array();
if ( post_type_exists( 'calculator' ) ) {
	$pop = get_posts( array( 'post_type' => 'calculator', 'posts_per_page' => 8, 'meta_key' => '_cw_popular', 'meta_value' => '1', 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true ) );
}
$lang_n   = function_exists( 'cw_ui_lang_config' ) ? count( cw_ui_lang_config()['enabled'] ) : 1;
$sub_h2   = cwt_t( 'hero_h2' );
$lead     = $hero['sub'] ? $hero['sub'] : str_replace( '{n}', number_format_i18n( $total ), cwt_t( 'hero_sub' ) );

?>

<section class="hero">
	<div class="wrap hero-in">
		<h1 class="js-hero-title"<?php echo $hero['custom'] ? '' : ' data-i="hero_title"'; // phpcs:ignore ?>><?php foreach ( $hero['lines'] as $line ) : ?><span class="l"><?php echo esc_html( $line ); ?></span><?php endforeach; ?></h1>
		<h2 class="hero-h2" <?php echo cwt_di( 'hero_h2' ); // phpcs:ignore ?>><?php echo esc_html( $sub_h2 ); ?></h2>
		<p class="hero-lead" <?php echo $hero['sub'] ? '' : cwt_dn( 'hero_sub', $total ); // phpcs:ignore ?>><?php echo esc_html( $lead ); ?></p>

		<div class="hs-wrap">
			<form class="hsearch js-hero-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
				<?php echo cwt_icon( 'search', 22 ); // phpcs:ignore ?>
				<input type="search" name="s" class="js-hero-input" data-ph="search_ph" aria-label="<?php esc_attr_e( 'Search', 'calcyworld' ); ?>" placeholder="<?php echo esc_attr( $ph ); ?>" autocomplete="off" spellcheck="false" role="combobox" aria-expanded="false" aria-controls="hs-list" aria-autocomplete="list">
				<button type="submit" class="btn" <?php echo cwt_di( 'search' ); // phpcs:ignore ?>><?php cwt_e( 'search' ); ?></button>
			</form>
			<ul class="hs-list" id="hs-list" role="listbox" hidden></ul>
		</div>

		<nav class="hcats" aria-label="<?php esc_attr_e( 'Categories', 'calcyworld' ); ?>">
			<?php if ( $pid( 'all-calculators' ) ) : ?><a class="is-main" href="<?php echo esc_url( get_permalink( $pid( 'all-calculators' ) ) ); ?>" <?php echo cwt_di( 'calculators' ); // phpcs:ignore ?>><?php cwt_e( 'calculators' ); ?></a><?php endif; ?>
			<?php if ( $pid( 'all-converters' ) ) : ?><a class="is-main" href="<?php echo esc_url( get_permalink( $pid( 'all-converters' ) ) ); ?>" <?php echo cwt_di( 'converters' ); // phpcs:ignore ?>><?php cwt_e( 'converters' ); ?></a><?php endif; ?>
			<?php foreach ( array_slice( $sections, 0, 12 ) as $s ) : if ( 'converters' === $s->slug ) { continue; } ?>
				<a href="<?php echo esc_url( get_term_link( $s ) ); ?>"<?php echo cwt_term_di( $s ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></a>
			<?php endforeach; ?>
			<?php if ( $pid( 'categories' ) ) : ?><a href="<?php echo esc_url( get_permalink( $pid( 'categories' ) ) ); ?>" <?php echo cwt_di( 'all_categories' ); // phpcs:ignore ?>><?php cwt_e( 'all_categories' ); ?></a><?php endif; ?>
		</nav>
	</div>
</section>

<?php if ( cwt_mod( 'cwt_show_stats' ) && $total ) : ?>
<section class="wrap">
	<div class="numbers">
		<div class="num"><b><?php echo esc_html( number_format_i18n( $total ) ); ?></b><span <?php echo cwt_di( 'stat_tools' ); // phpcs:ignore ?>><?php cwt_e( 'stat_tools' ); ?></span><small <?php echo cwt_di( 'tools_note' ); // phpcs:ignore ?>><?php cwt_e( 'tools_note' ); ?></small></div>
		<div class="num"><b><?php echo esc_html( count( $sections ) ); ?></b><span <?php echo cwt_di( 'stat_cats' ); // phpcs:ignore ?>><?php cwt_e( 'stat_cats' ); ?></span><small<?php echo cwt_dn( 'n_subcats', $groups ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'n_subcats', array( 'n' => $groups ) ) ); ?></small></div>
		<div class="num"><b class="js-n-cur">160+</b><span <?php echo cwt_di( 'stat_currencies' ); // phpcs:ignore ?>><?php cwt_e( 'stat_currencies' ); ?></span><small <?php echo cwt_di( 'cur_note' ); // phpcs:ignore ?>><?php cwt_e( 'cur_note' ); ?></small></div>
		<div class="num"><b><?php echo (int) $lang_n; ?></b><span <?php echo cwt_di( 'stat_langs' ); // phpcs:ignore ?>><?php cwt_e( 'stat_langs' ); ?></span><small <?php echo cwt_di( 'lang_note' ); // phpcs:ignore ?>><?php cwt_e( 'lang_note' ); ?></small></div>
	</div>
</section>
<?php endif; ?>

<?php if ( $pop ) : ?>
<section class="wrap block">
	<div class="blk-h">
		<div><h2 class="js-popular-title" data-tpl="<?php echo esc_attr( cwt_t( 'popular_in' ) ); ?>"><?php echo esc_html( cwt_t( 'popular' ) ); ?></h2><p class="js-popular-sub" data-tpl="<?php echo esc_attr( cwt_t( 'popular_sub' ) ); ?>"></p></div>
		<?php if ( $pid( 'popular' ) ) : ?><a class="more" href="<?php echo esc_url( get_permalink( $pid( 'popular' ) ) ); ?>"><span <?php echo cwt_di( 'view_all' ); // phpcs:ignore ?>><?php cwt_e( 'view_all' ); ?></span> <?php echo cwt_icon( 'arrow', 16 ); // phpcs:ignore ?></a><?php endif; ?>
	</div>
	<ul class="pcards js-popular-grid">
		<?php foreach ( $pop as $p ) : $sec = cw_post_section( $p->ID ); ?>
			<li><a class="pcard" href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo cwt_tile( 't', cwt_post_icon( $p ), 48, 'pc-i' ); // phpcs:ignore ?><span class="pc-t"><strong><?php echo esc_html( get_the_title( $p ) ); ?></strong><small><?php echo esc_html( $sec ? cwt_term_name( $sec ) : '' ); ?></small></span></a></li>
		<?php endforeach; ?>
	</ul>
</section>
<?php endif; ?>

<?php if ( $sections ) : ?>
<section class="wrap block" id="categories">
	<div class="blk-h"><h2 <?php echo cwt_di( 'browse_cat' ); // phpcs:ignore ?>><?php cwt_e( 'browse_cat' ); ?></h2><?php if ( $pid( 'categories' ) ) : ?><a class="more" href="<?php echo esc_url( get_permalink( $pid( 'categories' ) ) ); ?>"><span <?php echo cwt_di( 'all_categories' ); // phpcs:ignore ?>><?php cwt_e( 'all_categories' ); ?></span> <?php echo cwt_icon( 'arrow', 16 ); // phpcs:ignore ?></a><?php endif; ?></div>
	<ul class="ccards">
		<?php foreach ( $sections as $s ) : $subs = cwt_subs( $s->term_id ); $teaser = array(); foreach ( array_slice( $subs, 0, 3 ) as $t ) { $teaser[] = cwt_term_name( $t ); } ?>
			<li><a class="ccard" href="<?php echo esc_url( get_term_link( $s ) ); ?>">
				<?php echo cwt_tile( 'c', $s->slug, 56, 'cc-i' ); // phpcs:ignore ?>
				<span class="cc-b"><strong<?php echo cwt_term_di( $s ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></strong><span class="cc-n"<?php echo cwt_dn( 'tools_n', cwt_count( $s ) ); // phpcs:ignore ?>><?php echo esc_html( cwt_t( 'tools_n', array( 'n' => number_format_i18n( cwt_count( $s ) ) ) ) ); ?></span><span class="cc-s"><?php echo esc_html( implode( ', ', $teaser ) ); ?></span></span>
			</a></li>
		<?php endforeach; ?>
	</ul>
</section>

<section class="wrap block" id="finder">
	<div class="blk-h"><h2 <?php echo cwt_di( 'find_sub' ); // phpcs:ignore ?>><?php cwt_e( 'find_sub' ); ?></h2></div>
	<div class="explorer">
		<ul class="ex-list" role="tablist" aria-orientation="vertical">
			<?php foreach ( $sections as $i => $s ) : ?>
				<li><button type="button" class="ex-btn<?php echo 0 === $i ? ' is-on' : ''; ?>" role="tab" aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>" aria-controls="ex-<?php echo esc_attr( $s->slug ); ?>" data-ex="<?php echo esc_attr( $s->slug ); ?>"><?php echo cwt_ci( $s->slug, 22, 'ex-ic' ); // phpcs:ignore ?><span<?php echo cwt_term_di( $s ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></span><small><?php echo esc_html( number_format_i18n( cwt_count( $s ) ) ); ?></small></button></li>
			<?php endforeach; ?>
		</ul>
		<div class="ex-panels">
			<?php foreach ( $sections as $i => $s ) : $subs = cwt_subs( $s->term_id ); ?>
				<div class="ex-panel" id="ex-<?php echo esc_attr( $s->slug ); ?>" role="tabpanel" data-ex-panel="<?php echo esc_attr( $s->slug ); ?>" <?php echo 0 === $i ? '' : 'hidden'; ?>>
					<div class="ex-top">
						<div class="ex-ph">
							<h3><a href="<?php echo esc_url( get_term_link( $s ) ); ?>"<?php echo cwt_term_di( $s ); // phpcs:ignore ?>><?php echo esc_html( cwt_term_name( $s ) ); ?></a></h3>
							<p><?php echo esc_html( wp_strip_all_tags( term_description( $s->term_id, 'calc_category' ) ) ); ?></p>
							<a class="more" href="<?php echo esc_url( get_term_link( $s ) ); ?>"><span <?php echo cwt_di( 'view_all' ); // phpcs:ignore ?>><?php cwt_e( 'view_all' ); ?></span> <?php echo cwt_icon( 'arrow', 16 ); // phpcs:ignore ?></a>
						</div>
						<?php echo cwt_tile( 'c', $s->slug, 76 ); // phpcs:ignore ?>
					</div>
					<ul class="ex-links">
						<?php foreach ( $subs as $t ) : ?>
							<li><a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><span><?php echo esc_html( cwt_term_name( $t ) ); ?></span><small><?php echo esc_html( number_format_i18n( cwt_count( $t ) ) ); ?></small></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( cwt_mod( 'cwt_show_rates' ) ) :
	$cc_post = function_exists( 'cw_find_post_by_engine' ) ? cw_find_post_by_engine( 'currency-converter' ) : 0; ?>
<section class="wrap block">
	<div class="rates-panel">
		<div class="rp-l">
			<span class="rp-badge"><i></i><span <?php echo cwt_di( 'auto_daily' ); // phpcs:ignore ?>><?php cwt_e( 'auto_daily' ); ?></span></span>
			<h2 <?php echo cwt_di( 'live_rates' ); // phpcs:ignore ?>><?php cwt_e( 'live_rates' ); ?></h2>
			<?php if ( $cc_post ) : ?><a class="rp-btn" href="<?php echo esc_url( get_permalink( $cc_post ) ); ?>" <?php echo cwt_di( 'open_converter' ); // phpcs:ignore ?>><?php cwt_e( 'open_converter' ); ?></a><?php endif; ?>
		</div>
		<ul class="rp-list js-rates"></ul>
	</div>
</section>
<?php endif; ?>

<?php if ( cwt_mod( 'cwt_show_blog' ) ) :
	$posts = get_posts( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
	if ( $posts ) : ?>
<section class="wrap block">
	<div class="blk-h"><h2 <?php echo cwt_di( 'latest_posts' ); // phpcs:ignore ?>><?php cwt_e( 'latest_posts' ); ?></h2><?php if ( get_option( 'page_for_posts' ) ) : ?><a class="more" href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>"><span <?php echo cwt_di( 'view_all' ); // phpcs:ignore ?>><?php cwt_e( 'view_all' ); ?></span> <?php echo cwt_icon( 'arrow', 16 ); // phpcs:ignore ?></a><?php endif; ?></div>
	<ul class="posts">
		<?php foreach ( $posts as $p ) : ?>
			<li><?php cwt_post_card( $p ); ?></li>
		<?php endforeach; ?>
	</ul>
</section>
<?php endif; endif; ?>

<?php
while ( have_posts() ) :
	the_post();
	if ( trim( get_the_content() ) ) {
		echo '<section class="wrap block"><div class="seo prose">';
		the_content();
		echo '</div></section>';
	}
endwhile;
get_footer();
