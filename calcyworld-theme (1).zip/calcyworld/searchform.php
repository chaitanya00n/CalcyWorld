<?php
/**
 * Search form.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
$cwt_sid = 's-' . wp_unique_id();
?>
<form role="search" method="get" class="hsearch" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $cwt_sid ); ?>"><?php cwt_e( 'search' ); ?></label>
	<?php echo cwt_icon( 'search', 22 ); // phpcs:ignore ?>
	<input type="search" id="<?php echo esc_attr( $cwt_sid ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( cwt_t( 'search_ph' ) ); ?>" autocomplete="off">
	<button type="submit" class="btn"><?php cwt_e( 'search' ); ?></button>
</form>
