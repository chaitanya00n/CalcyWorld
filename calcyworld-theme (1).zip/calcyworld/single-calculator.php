<?php
/**
 * A single calculator or converter: a slim bar (back, more tools, name), the tool itself with its result cards,
 * then "More about this tool" — description, formula, FAQ and related tools. Every part is editable in WordPress.
 *
 * @package Calcyworld
 */

defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$id      = get_the_ID();
	$sec     = function_exists( 'cw_post_section' ) ? cw_post_section( $id ) : null;
	$terms   = get_the_terms( $id, 'calc_category' );
	$group   = $terms && ! is_wp_error( $terms ) ? $terms[0] : null;
	$back    = $group ? get_term_link( $group ) : home_url( '/' );
	$is_conv = $sec && 'converters' === $sec->slug;
	$all_id  = function_exists( 'cw_page_id' ) ? cw_page_id( $is_conv ? 'all-converters' : 'all-calculators' ) : 0;
	$all_url = $all_id ? get_permalink( $all_id ) : home_url( '/' );
	$formula = trim( (string) get_post_meta( $id, '_cw_formula', true ) );
	$faq     = array();
	if ( cwt_core() ) {
		$faq = array_merge( cw_parse_faq( get_post_meta( $id, '_cw_faq', true ) ), cw_standard_faq( $id ) );
	}
	$related  = cwt_core() ? cw_related_ids( $id, 8 ) : array();
	$has_side = is_active_sidebar( 'calc-sidebar' ) || ( function_exists( 'cw_ad_html' ) && cw_ad_html( 'sidebar' ) );
	?>
	<article <?php post_class( 'calc-page' ); ?> data-sec="<?php echo esc_attr( $sec ? $sec->slug : '' ); ?>">
		<div class="wrap">
			<?php cwt_breadcrumbs(); ?>
			<div class="calc-bar">
				<a class="ibtn back" href="<?php echo esc_url( $back ); ?>" aria-label="<?php echo esc_attr( cwt_t( 'back' ) ); ?>"><?php echo cwt_icon( 'back', 20 ); // phpcs:ignore ?></a>
				<a class="more-tools" href="<?php echo esc_url( $all_url ); ?>"><?php echo cwt_icon( 'tiles', 18 ); // phpcs:ignore ?><span <?php echo cwt_di( 'more_tools' ); // phpcs:ignore ?>><?php cwt_e( 'more_tools' ); ?></span></a>
				<div class="calc-name"><?php echo cwt_tile( 't', cwt_post_icon( get_post() ), 34, 'calc-i' ); // phpcs:ignore ?><h1><?php the_title(); ?></h1><span class="free-tag" <?php echo cwt_di( 'free_tag' ); // phpcs:ignore ?>><?php cwt_e( 'free_tag' ); ?></span></div>
			</div>

			<section class="calc-tool" aria-label="<?php the_title_attribute(); ?>">
				<?php echo cwt_core() ? cw_render_widget( $id ) : '<p>' . esc_html__( 'Activate the Calcyworld Core plugin to show calculators.', 'calcyworld' ) . '</p>'; // phpcs:ignore ?>
			</section>

			<?php cwt_ad( 'below_tool' ); ?>

			<section class="more-sec" id="more">
				<div class="more-grid<?php echo $has_side ? ' has-side' : ''; ?>">
					<div class="more-main">
						<?php if ( trim( get_the_content() ) ) : ?>
							<div class="prose card-box calc-article"><h2 <?php echo cwt_di( 'more_about' ); // phpcs:ignore ?>><?php cwt_e( 'more_about' ); ?></h2><?php the_content(); ?></div>
						<?php endif; ?>
						<?php if ( $formula ) : ?>
							<div class="formula-card" id="formula">
								<h3 <?php echo cwt_di( 'formula' ); // phpcs:ignore ?>><?php cwt_e( 'formula' ); ?></h3>
								<p><?php echo wp_kses_post( $formula ); ?></p>
							</div>
						<?php endif; ?>
					</div>
					<?php if ( $has_side ) : ?>
						<aside class="more-side">
							<?php cwt_ad( 'sidebar' ); ?>
							<?php dynamic_sidebar( 'calc-sidebar' ); ?>
						</aside>
					<?php endif; ?>
				</div>

				<?php if ( $faq ) : ?>
					<div class="blk-h"><h2 <?php echo cwt_di( 'faq' ); // phpcs:ignore ?>><?php cwt_e( 'faq' ); ?></h2></div>
					<?php echo cwt_faq_html( $faq ); // phpcs:ignore ?>
				<?php endif; ?>

				<?php if ( $related ) : ?>
					<div class="blk-h"><h2 <?php echo cwt_di( 'related' ); // phpcs:ignore ?>><?php cwt_e( 'related' ); ?></h2></div>
					<ul class="tgrid">
						<?php foreach ( $related as $rid ) { cwt_card( $rid ); } ?>
					</ul>
				<?php endif; ?>

				<?php $disc = function_exists( 'cw_settings' ) ? cw_settings()['disclaimer'] : ''; ?>
				<?php if ( $disc ) : ?><p class="calc-disclaimer"><?php echo esc_html( $disc ); ?></p><?php endif; ?>
			</section>
		</div>
	</article>
	<?php
endwhile;
get_footer();
